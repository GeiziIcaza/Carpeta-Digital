package NumeroPerfecto;
public class NumeroPerfecto {
    private int numero;

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getNumero() {
        return numero;
    }

    public boolean EvaluarPerfecto() {
        int divisor = 1;
        int suma = 0;
        while (divisor < numero) {
            if (numero % divisor == 0) {
                suma = suma + divisor;
            }
            divisor++;
        }
        return suma == numero;
    }
}