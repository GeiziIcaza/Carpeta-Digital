package NumeroPerfecto;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class MainNumeroPerfecto {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        NumeroPerfecto obj = new NumeroPerfecto();
        int numero;
        boolean repetir = true;
        do {
            try {
                System.out.println("Ingrese un numero natural:");
                numero = Integer.parseInt(br.readLine());
                while (numero <= 0) {
                    System.out.println("Error. El numero debe ser natural y mayor que 0.");
                    System.out.println("Ingrese nuevamente:");
                    numero = Integer.parseInt(br.readLine());
                }
                obj.setNumero(numero);
                if (obj.EvaluarPerfecto()) {

                    System.out.println(
                            "El numero " + numero + " es perfecto.");

                } else {

                    System.out.println(
                            "El numero " + numero + " no es perfecto.");
                }
                repetir = false;

            } catch (NumberFormatException e) {
                System.out.println("Error. Debe ingresar un numero entero.");
                repetir = true;

            } catch (Exception e) {
                System.out.println("Ocurrio un error.");
            }
        } while (repetir);
    }
}