package Limites;
public class Limites {
    private int limiteInferior;
    private int limiteSuperior;
    private int suma = 0;
    private int fueraIntervalo = 0;
    private boolean igual = false;

    public void setLimiteInferior(int limiteInferior) {
        this.limiteInferior = limiteInferior;
    }
    public int getLimiteInferior() {
        return limiteInferior;
    }
    public void setLimiteSuperior(int limiteSuperior) {
        this.limiteSuperior = limiteSuperior;
    }
    public int getLimiteSuperior() {
        return limiteSuperior;
    }

    public int getSuma() {
        return suma;
    }

    public int getFueraIntervalo() {
        return fueraIntervalo;
    }

    public boolean getIgual() {
        return igual;
    }

    public void EvaluarNumero(int numero) {

        if (numero >= limiteInferior && numero <= limiteSuperior) {
                suma = suma + numero;
        } else {
                fueraIntervalo++;
        }

        if (numero == limiteInferior || numero == limiteSuperior) {
                igual = true;
        }
    }
}
