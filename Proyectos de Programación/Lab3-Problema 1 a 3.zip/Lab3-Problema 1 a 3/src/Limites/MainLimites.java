package Limites;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class MainLimites {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Limites obj = new Limites();
        int limiteInferior;
        int limiteSuperior;
        int numero;
        boolean repetir= false;
        do {
            try {

                System.out.println("Ingresar el límite inferior:");
                limiteInferior = Integer.parseInt(br.readLine());

                System.out.println("Ingresar el límite superior:");
                limiteSuperior = Integer.parseInt(br.readLine());

                while (limiteInferior > limiteSuperior) {

                    System.out.println("El límite superior debe ser mayor que el inferior.");

                    System.out.println("Ingresar el limite inferior:");
                    limiteInferior = Integer.parseInt(br.readLine());

                    System.out.println("Ingresar el limite superior:");
                    limiteSuperior = Integer.parseInt(br.readLine());
                }
                obj.setLimiteInferior(limiteInferior);
                obj.setLimiteSuperior(limiteSuperior);

                do {
                    System.out.println("Ingrese un número:");
                    System.out.println("Ingrese 0 para evaluar");
                    numero = Integer.parseInt(br.readLine());
                    if (numero != 0) {
                        obj.EvaluarNumero(numero);
                    }
                } while (numero != 0);

                System.out.println("El total de la suma de los numeros dentro del intervalo es: "
                        + obj.getSuma());

                System.out.println("Hay " + obj.getFueraIntervalo() + " numeros fuera del intervalo");

                if (obj.getIgual() == true) {
                    System.out.println("Se ingreso un numero igual a uno de los limites.");
                } else {
                    System.out.println("No se ingreso ningun numero igual a los limites.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error, debe ingresar un numero.");
                repetir= true;

            } catch (Exception e) {
                System.out.println("Error general.");
            }
        } while (repetir == true);
    }
}




