package Coseno;
public class Coseno {

    private double numero;

    public double getNumero() {
        return numero;
    }

    public void setNumero(double numero) {
        this.numero = numero;
    }

    public double calcularCoseno() {

        double valor = numero % (2 * Math.PI);

        double suma = 0;
        double termino;
        int n = 0;

        do {

            // (-1)^n
            double signo = Math.pow(-1, n);

            // numero^(2n)
            double potencia = Math.pow(valor, 2 * n);

            // (2n)!
            double factorial = factorial(2 * n);

            // (-1)^n * numero^(2n) / (2n)!
            termino = signo * potencia / factorial;
            suma = suma + termino;
            n++;
        } while (Math.abs(termino) > 0.000001);
        return suma;
    }

    public double factorial(int numero) {
        double resultado = 1;
        int i = 1;
        while (i <= numero) {
            resultado = resultado * i;
            i++;
        }
        return resultado;
    }
}