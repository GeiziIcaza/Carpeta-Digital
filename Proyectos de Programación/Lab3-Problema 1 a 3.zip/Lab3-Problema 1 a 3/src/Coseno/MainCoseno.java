package Coseno;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class MainCoseno {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Coseno obj = new Coseno();
        double numero;
        double resultadoSerie;
        double resultadoMath;
        double diferencia;
        boolean repetir = false;
        do {
            try {

                System.out.println("Ingresar un numero de tres cifras:");
                numero = Double.parseDouble(br.readLine());

                while (numero < 100 || numero > 999) {
                    System.out.println("Error. El numero debe tener tres cifras.");
                    System.out.println("Ingrese nuevamente:");
                    numero = Double.parseDouble(br.readLine());
                }
                obj.setNumero(numero);
                resultadoSerie = obj.calcularCoseno();
                resultadoMath = Math.cos(numero);
                diferencia = Math.abs(resultadoSerie - resultadoMath);

                System.out.println("Resultado mediante la serie: " + resultadoSerie);
                System.out.println("Resultado mediante Math.cos: " + resultadoMath);
                System.out.println("La diferencia entre ambos resultados es: " + diferencia);
            } catch (NumberFormatException e) {
                System.out.println("Debe ingresar un numero.");
                repetir = true;
            } catch (Exception e) {
                System.out.println("Ocurrio un error.");
            }
        } while (repetir== true);
    }
}
