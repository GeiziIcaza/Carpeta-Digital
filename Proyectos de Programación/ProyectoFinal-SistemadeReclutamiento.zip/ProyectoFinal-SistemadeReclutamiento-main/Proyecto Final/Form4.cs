﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Final
{
    public partial class Form4 : Form
    {
        private string puestoSeleccionado;
        private Vacante vacanteActual;
        public Form4(string puesto)
        {
            InitializeComponent();
            puestoSeleccionado = puesto;
        }

        private void TxtNombre_Leave(object sender, EventArgs e)
        {
            txtNombre.Text = txtNombre.Text.ToUpper();
        }
        private void Form4_Load(object sender, EventArgs e)
        {
            vacanteActual =  Form1.evaluacion.BuscarVacante(puestoSeleccionado);
            if (vacanteActual != null)
            {
                lbInformacion.Text =
                    "Puesto: " + vacanteActual.NombrePuesto +
                    "\nDepartamento: " + vacanteActual.Departamento +
                    "\nSalario: B/. " + vacanteActual.Salario.ToString("N2") +
                    "\nNivel académico: " + vacanteActual.NivelAcademico +
                    "\nExperiencia requerida: " + vacanteActual.Experiencia + " años" +
                    "\n\nHabilidades requeridas:";

                for (int i = 0; i < vacanteActual.HabilidadesRequeridas.Length; i++)
                {
                    lbInformacion.Text +=
                        "\n• " + vacanteActual.HabilidadesRequeridas[i];
                }

                CargarHabilidades();
            }
        }

        // Carga las habilidades en los CheckBox
        private void CargarHabilidades()
        {
            CheckBox[] habilidades =
            {
                chHabilidad1,
                chHabilidad2,
                chHabilidad3,
                chHabilidad4,
                chHabilidad5,
                chHabilidad6
            };

            for (int i = 0; i < habilidades.Length; i++)
            {
                habilidades[i].Text = "";
                habilidades[i].Checked = false;
            }

            int posicion = 0;

            for (int i = 0; i < vacanteActual.HabilidadesRequeridas.Length; i++)
            {
                habilidades[posicion].Text = vacanteActual.HabilidadesRequeridas[i];
                posicion++;
            }

            for (int i = 0; i < vacanteActual.HabilidadesExtras.Length; i++)
            {
                habilidades[posicion].Text = vacanteActual.HabilidadesExtras[i];
                posicion++;
            }
        }

        private void BtGuardarEvaluacion_Click(object sender, EventArgs e)
        {

            try
            {
                // Validaciones
                if (txtNombre.Text.Trim() == "")
                {
                    MessageBox.Show("Ingrese el nombre del candidato.");
                    txtNombre.Focus();
                    return;
                }

                if (txtNombre.Text.Trim().Length < 3)
                {
                    MessageBox.Show("El nombre debe tener al menos 3 caracteres.");
                    txtNombre.Focus();
                    return;
                }

                if (txtCedula.Text.Trim() == "")
                {
                    MessageBox.Show("Ingrese la cédula.");
                    txtCedula.Focus();
                    return;
                }

                if (Form1.evaluacion.EvitarRepetirCedula(txtCedula.Text))
                {
                    MessageBox.Show("Ya existe un candidato registrado con esa cédula.");
                    txtCedula.Focus();
                    return;
                }

                if (txtCorreo.Text.Trim() == "")
                { MessageBox.Show("Ingrese el correo.");
                    txtCorreo.Focus();
                    return;
                }

                if (!txtCorreo.Text.Contains("@") ||
                    !txtCorreo.Text.Contains("."))
                {
                    MessageBox.Show("Ingrese un correo válido.");
                    txtCorreo.Focus();
                    return;
                }

                if (txtExperiencia.Text.Trim() == "")
                {
                    MessageBox.Show("Ingrese la experiencia.");
                    txtExperiencia.Focus();
                    return;
                }

                if (cbNivelAcademico.SelectedIndex == -1)
                {
                    MessageBox.Show("Seleccione el nivel académico.");
                    cbNivelAcademico.Focus();
                    return;
                }

                int experiencia;

                if (!int.TryParse(txtExperiencia.Text, out experiencia))
                {
                    MessageBox.Show("La experiencia debe ser numérica.");
                    txtExperiencia.Focus();
                    return;
                }

                if (experiencia < 0)
                {
                    MessageBox.Show("La experiencia no puede ser negativa.");
                    txtExperiencia.Focus();
                    return;
                }

                if (experiencia > 50)
                {
                    MessageBox.Show("La experiencia no puede ser mayor a 50 años.");
                    txtExperiencia.Focus();
                    return;
                }

                Candidato candidato = new Candidato();
                candidato.Nombre = txtNombre.Text.Trim();
                candidato.Cedula = txtCedula.Text.Trim();
                candidato.Correo = txtCorreo.Text.Trim();
                candidato.Experiencia = experiencia;
                candidato.Vacante = vacanteActual.NombrePuesto;
                bool[] habilidades =
                {
                    chHabilidad1.Checked,
                    chHabilidad2.Checked,
                    chHabilidad3.Checked,
                    chHabilidad4.Checked,
                    chHabilidad5.Checked,
                    chHabilidad6.Checked
                };

                candidato.NivelAcademico = cbNivelAcademico.Text;
                candidato.AspiracionSalarial = Convert.ToDouble(txtAspiracionSalario.Text);
                candidato.Puntaje = candidato.CalcularPuntajeTotal( vacanteActual,habilidades,
                    trbPresentacion.Value,trbComunicacion.Value,trbActitud.Value,trbAspiracion.Value);

                bool guardado = Form1.evaluacion.AgregarCandidato(candidato);

                if (guardado)
                {
                    MessageBox.Show(
                        "Evaluación guardada correctamente.",
                        "Sistema RRHH",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    Limpiar();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("No fue posible guardar el candidato.");
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error");
            }
        }

        private void TxtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) &&
                !char.IsWhiteSpace(e.KeyChar) &&
                e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void TxtCedula_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = char.ToUpper(e.KeyChar);

            if (!char.IsDigit(e.KeyChar) &&
                letra != 'E' &&
                letra != 'N' &&
                letra != 'P' &&
                e.KeyChar != '-' &&
                e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }
        // Limpia el formulario
        private void Limpiar()
        {
            txtNombre.Clear();
            txtCedula.Clear();
            txtCorreo.Clear();
            txtExperiencia.Clear();

            trbPresentacion.Value = 1;
            trbComunicacion.Value = 1;
            trbActitud.Value = 1;
            trbAspiracion.Value = 1;

            CheckBox[] habilidades =
            {
                chHabilidad1,
                chHabilidad2,
                chHabilidad3,
                chHabilidad4,
                chHabilidad5,
                chHabilidad6
            };

            for (int i = 0; i < habilidades.Length; i++)
            {
                habilidades[i].Checked = false;
            }
        }

        private void PbAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }
    }
}