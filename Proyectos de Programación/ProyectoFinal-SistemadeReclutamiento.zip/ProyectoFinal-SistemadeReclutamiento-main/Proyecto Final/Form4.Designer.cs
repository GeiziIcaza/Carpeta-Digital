﻿namespace Proyecto_Final
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panEvaluarCandidatos = new System.Windows.Forms.Panel();
            this.pbAtras2 = new System.Windows.Forms.PictureBox();
            this.lbTituloEvaluarCandidato = new System.Windows.Forms.Label();
            this.lbSphere5 = new System.Windows.Forms.Label();
            this.lbCode5 = new System.Windows.Forms.Label();
            this.pbLogo5 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtAspiracionSalario = new System.Windows.Forms.TextBox();
            this.lbNivelAcademico = new System.Windows.Forms.Label();
            this.cbNivelAcademico = new System.Windows.Forms.ComboBox();
            this.lbSalario = new System.Windows.Forms.Label();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.lbCorreo = new System.Windows.Forms.Label();
            this.panSeleccionHabilidades = new System.Windows.Forms.Panel();
            this.chHabilidad5 = new System.Windows.Forms.CheckBox();
            this.chHabilidad6 = new System.Windows.Forms.CheckBox();
            this.chHabilidad2 = new System.Windows.Forms.CheckBox();
            this.chHabilidad4 = new System.Windows.Forms.CheckBox();
            this.chHabilidad3 = new System.Windows.Forms.CheckBox();
            this.chHabilidad1 = new System.Windows.Forms.CheckBox();
            this.lbSeleccionHabilidades = new System.Windows.Forms.Label();
            this.txtExperiencia = new System.Windows.Forms.TextBox();
            this.lbExperiencia = new System.Windows.Forms.Label();
            this.txtCedula = new System.Windows.Forms.TextBox();
            this.lbCedula = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.lbNombre = new System.Windows.Forms.Label();
            this.lbDatosDelCandidato = new System.Windows.Forms.Label();
            this.lbTituloInformacionDelPuesto = new System.Windows.Forms.Label();
            this.lbTituloEntrevistador = new System.Windows.Forms.Label();
            this.lbPresentacion = new System.Windows.Forms.Label();
            this.lbComunicacion = new System.Windows.Forms.Label();
            this.lbActitud = new System.Windows.Forms.Label();
            this.lbAspiracion = new System.Windows.Forms.Label();
            this.trbPresentacion = new System.Windows.Forms.TrackBar();
            this.trbComunicacion = new System.Windows.Forms.TrackBar();
            this.trbActitud = new System.Windows.Forms.TrackBar();
            this.trbAspiracion = new System.Windows.Forms.TrackBar();
            this.btGuardarEvaluacion = new System.Windows.Forms.Button();
            this.lbInformacion = new System.Windows.Forms.Label();
            this.btLimpiar = new System.Windows.Forms.Button();
            this.panEvaluarCandidatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAtras2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo5)).BeginInit();
            this.panel2.SuspendLayout();
            this.panSeleccionHabilidades.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trbPresentacion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trbComunicacion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trbActitud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trbAspiracion)).BeginInit();
            this.SuspendLayout();
            // 
            // panEvaluarCandidatos
            // 
            this.panEvaluarCandidatos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.panEvaluarCandidatos.Controls.Add(this.pbAtras2);
            this.panEvaluarCandidatos.Controls.Add(this.lbTituloEvaluarCandidato);
            this.panEvaluarCandidatos.Controls.Add(this.lbSphere5);
            this.panEvaluarCandidatos.Controls.Add(this.lbCode5);
            this.panEvaluarCandidatos.Controls.Add(this.pbLogo5);
            this.panEvaluarCandidatos.Location = new System.Drawing.Point(1, 0);
            this.panEvaluarCandidatos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panEvaluarCandidatos.Name = "panEvaluarCandidatos";
            this.panEvaluarCandidatos.Size = new System.Drawing.Size(1971, 94);
            this.panEvaluarCandidatos.TabIndex = 2;
            // 
            // pbAtras2
            // 
            this.pbAtras2.Image = global::Proyecto_Final.Properties.Resources.atras;
            this.pbAtras2.InitialImage = null;
            this.pbAtras2.Location = new System.Drawing.Point(36, 12);
            this.pbAtras2.Name = "pbAtras2";
            this.pbAtras2.Size = new System.Drawing.Size(70, 53);
            this.pbAtras2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbAtras2.TabIndex = 20;
            this.pbAtras2.TabStop = false;
            this.pbAtras2.Click += new System.EventHandler(this.PbAtras_Click);
            // 
            // lbTituloEvaluarCandidato
            // 
            this.lbTituloEvaluarCandidato.AutoSize = true;
            this.lbTituloEvaluarCandidato.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTituloEvaluarCandidato.ForeColor = System.Drawing.Color.White;
            this.lbTituloEvaluarCandidato.Location = new System.Drawing.Point(127, 25);
            this.lbTituloEvaluarCandidato.Name = "lbTituloEvaluarCandidato";
            this.lbTituloEvaluarCandidato.Size = new System.Drawing.Size(208, 26);
            this.lbTituloEvaluarCandidato.TabIndex = 17;
            this.lbTituloEvaluarCandidato.Text = "Evaluar Candidato";
            // 
            // lbSphere5
            // 
            this.lbSphere5.AutoSize = true;
            this.lbSphere5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSphere5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(189)))), ((int)(((byte)(248)))));
            this.lbSphere5.Location = new System.Drawing.Point(1723, 36);
            this.lbSphere5.Name = "lbSphere5";
            this.lbSphere5.Size = new System.Drawing.Size(98, 29);
            this.lbSphere5.TabIndex = 5;
            this.lbSphere5.Text = "Sphere";
            // 
            // lbCode5
            // 
            this.lbCode5.AutoSize = true;
            this.lbCode5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCode5.ForeColor = System.Drawing.Color.White;
            this.lbCode5.Location = new System.Drawing.Point(1652, 36);
            this.lbCode5.Name = "lbCode5";
            this.lbCode5.Size = new System.Drawing.Size(76, 29);
            this.lbCode5.TabIndex = 4;
            this.lbCode5.Text = "Code";
            // 
            // pbLogo5
            // 
            this.pbLogo5.Image = global::Proyecto_Final.Properties.Resources.Captura_de_pantalla_2026_07_11_163634;
            this.pbLogo5.Location = new System.Drawing.Point(1528, 13);
            this.pbLogo5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pbLogo5.Name = "pbLogo5";
            this.pbLogo5.Size = new System.Drawing.Size(118, 74);
            this.pbLogo5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogo5.TabIndex = 3;
            this.pbLogo5.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.panel2.Controls.Add(this.txtAspiracionSalario);
            this.panel2.Controls.Add(this.lbNivelAcademico);
            this.panel2.Controls.Add(this.cbNivelAcademico);
            this.panel2.Controls.Add(this.lbSalario);
            this.panel2.Controls.Add(this.txtCorreo);
            this.panel2.Controls.Add(this.lbCorreo);
            this.panel2.Controls.Add(this.panSeleccionHabilidades);
            this.panel2.Controls.Add(this.lbSeleccionHabilidades);
            this.panel2.Controls.Add(this.txtExperiencia);
            this.panel2.Controls.Add(this.lbExperiencia);
            this.panel2.Controls.Add(this.txtCedula);
            this.panel2.Controls.Add(this.lbCedula);
            this.panel2.Controls.Add(this.txtNombre);
            this.panel2.Controls.Add(this.lbNombre);
            this.panel2.Controls.Add(this.lbDatosDelCandidato);
            this.panel2.Location = new System.Drawing.Point(563, 93);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(835, 907);
            this.panel2.TabIndex = 3;
            // 
            // txtAspiracionSalario
            // 
            this.txtAspiracionSalario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.txtAspiracionSalario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAspiracionSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAspiracionSalario.ForeColor = System.Drawing.Color.White;
            this.txtAspiracionSalario.Location = new System.Drawing.Point(540, 187);
            this.txtAspiracionSalario.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAspiracionSalario.MaxLength = 6;
            this.txtAspiracionSalario.Multiline = true;
            this.txtAspiracionSalario.Name = "txtAspiracionSalario";
            this.txtAspiracionSalario.Size = new System.Drawing.Size(148, 37);
            this.txtAspiracionSalario.TabIndex = 32;
            // 
            // lbNivelAcademico
            // 
            this.lbNivelAcademico.AutoSize = true;
            this.lbNivelAcademico.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.lbNivelAcademico.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNivelAcademico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbNivelAcademico.Location = new System.Drawing.Point(38, 325);
            this.lbNivelAcademico.Name = "lbNivelAcademico";
            this.lbNivelAcademico.Size = new System.Drawing.Size(187, 25);
            this.lbNivelAcademico.TabIndex = 45;
            this.lbNivelAcademico.Text = "Nivel Académico";
            // 
            // cbNivelAcademico
            // 
            this.cbNivelAcademico.BackColor = System.Drawing.Color.White;
            this.cbNivelAcademico.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbNivelAcademico.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbNivelAcademico.FormattingEnabled = true;
            this.cbNivelAcademico.Items.AddRange(new object[] {
            "Bachiller",
            "Técnico",
            "Licenciatura",
            "Posgrado",
            "Maestría",
            "Doctorado"});
            this.cbNivelAcademico.Location = new System.Drawing.Point(43, 364);
            this.cbNivelAcademico.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbNivelAcademico.Name = "cbNivelAcademico";
            this.cbNivelAcademico.Size = new System.Drawing.Size(433, 33);
            this.cbNivelAcademico.TabIndex = 44;
            // 
            // lbSalario
            // 
            this.lbSalario.AutoSize = true;
            this.lbSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSalario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbSalario.Location = new System.Drawing.Point(507, 152);
            this.lbSalario.Name = "lbSalario";
            this.lbSalario.Size = new System.Drawing.Size(210, 25);
            this.lbSalario.TabIndex = 31;
            this.lbSalario.Text = "Aspiración Salarial";
            // 
            // txtCorreo
            // 
            this.txtCorreo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.txtCorreo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCorreo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorreo.ForeColor = System.Drawing.Color.White;
            this.txtCorreo.Location = new System.Drawing.Point(38, 268);
            this.txtCorreo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCorreo.MaxLength = 100;
            this.txtCorreo.Multiline = true;
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(727, 38);
            this.txtCorreo.TabIndex = 30;
            // 
            // lbCorreo
            // 
            this.lbCorreo.AutoSize = true;
            this.lbCorreo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCorreo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbCorreo.Location = new System.Drawing.Point(38, 239);
            this.lbCorreo.Name = "lbCorreo";
            this.lbCorreo.Size = new System.Drawing.Size(83, 25);
            this.lbCorreo.TabIndex = 29;
            this.lbCorreo.Text = "Correo";
            // 
            // panSeleccionHabilidades
            // 
            this.panSeleccionHabilidades.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.panSeleccionHabilidades.Controls.Add(this.chHabilidad5);
            this.panSeleccionHabilidades.Controls.Add(this.chHabilidad6);
            this.panSeleccionHabilidades.Controls.Add(this.chHabilidad2);
            this.panSeleccionHabilidades.Controls.Add(this.chHabilidad4);
            this.panSeleccionHabilidades.Controls.Add(this.chHabilidad3);
            this.panSeleccionHabilidades.Controls.Add(this.chHabilidad1);
            this.panSeleccionHabilidades.Location = new System.Drawing.Point(38, 452);
            this.panSeleccionHabilidades.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panSeleccionHabilidades.Name = "panSeleccionHabilidades";
            this.panSeleccionHabilidades.Size = new System.Drawing.Size(727, 383);
            this.panSeleccionHabilidades.TabIndex = 28;
            // 
            // chHabilidad5
            // 
            this.chHabilidad5.AutoSize = true;
            this.chHabilidad5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chHabilidad5.ForeColor = System.Drawing.Color.White;
            this.chHabilidad5.Location = new System.Drawing.Point(33, 274);
            this.chHabilidad5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chHabilidad5.Name = "chHabilidad5";
            this.chHabilidad5.Size = new System.Drawing.Size(22, 21);
            this.chHabilidad5.TabIndex = 11;
            this.chHabilidad5.UseVisualStyleBackColor = true;
            // 
            // chHabilidad6
            // 
            this.chHabilidad6.AutoSize = true;
            this.chHabilidad6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chHabilidad6.ForeColor = System.Drawing.Color.White;
            this.chHabilidad6.Location = new System.Drawing.Point(33, 341);
            this.chHabilidad6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chHabilidad6.Name = "chHabilidad6";
            this.chHabilidad6.Size = new System.Drawing.Size(22, 21);
            this.chHabilidad6.TabIndex = 10;
            this.chHabilidad6.UseVisualStyleBackColor = true;
            // 
            // chHabilidad2
            // 
            this.chHabilidad2.AutoSize = true;
            this.chHabilidad2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chHabilidad2.ForeColor = System.Drawing.Color.White;
            this.chHabilidad2.Location = new System.Drawing.Point(33, 86);
            this.chHabilidad2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chHabilidad2.Name = "chHabilidad2";
            this.chHabilidad2.Size = new System.Drawing.Size(22, 21);
            this.chHabilidad2.TabIndex = 9;
            this.chHabilidad2.UseVisualStyleBackColor = true;
            // 
            // chHabilidad4
            // 
            this.chHabilidad4.AutoSize = true;
            this.chHabilidad4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chHabilidad4.ForeColor = System.Drawing.Color.White;
            this.chHabilidad4.Location = new System.Drawing.Point(33, 212);
            this.chHabilidad4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chHabilidad4.Name = "chHabilidad4";
            this.chHabilidad4.Size = new System.Drawing.Size(22, 21);
            this.chHabilidad4.TabIndex = 8;
            this.chHabilidad4.UseVisualStyleBackColor = true;
            // 
            // chHabilidad3
            // 
            this.chHabilidad3.AutoSize = true;
            this.chHabilidad3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chHabilidad3.ForeColor = System.Drawing.Color.White;
            this.chHabilidad3.Location = new System.Drawing.Point(33, 144);
            this.chHabilidad3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chHabilidad3.Name = "chHabilidad3";
            this.chHabilidad3.Size = new System.Drawing.Size(22, 21);
            this.chHabilidad3.TabIndex = 7;
            this.chHabilidad3.UseVisualStyleBackColor = true;
            // 
            // chHabilidad1
            // 
            this.chHabilidad1.AutoSize = true;
            this.chHabilidad1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chHabilidad1.ForeColor = System.Drawing.Color.White;
            this.chHabilidad1.Location = new System.Drawing.Point(33, 26);
            this.chHabilidad1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chHabilidad1.Name = "chHabilidad1";
            this.chHabilidad1.Size = new System.Drawing.Size(22, 21);
            this.chHabilidad1.TabIndex = 6;
            this.chHabilidad1.UseVisualStyleBackColor = true;
            // 
            // lbSeleccionHabilidades
            // 
            this.lbSeleccionHabilidades.AutoSize = true;
            this.lbSeleccionHabilidades.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSeleccionHabilidades.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbSeleccionHabilidades.Location = new System.Drawing.Point(33, 425);
            this.lbSeleccionHabilidades.Name = "lbSeleccionHabilidades";
            this.lbSeleccionHabilidades.Size = new System.Drawing.Size(285, 25);
            this.lbSeleccionHabilidades.TabIndex = 27;
            this.lbSeleccionHabilidades.Text = "Habilidades del candidato";
            // 
            // txtExperiencia
            // 
            this.txtExperiencia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.txtExperiencia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtExperiencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExperiencia.ForeColor = System.Drawing.Color.White;
            this.txtExperiencia.Location = new System.Drawing.Point(540, 359);
            this.txtExperiencia.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtExperiencia.MaxLength = 2;
            this.txtExperiencia.Multiline = true;
            this.txtExperiencia.Name = "txtExperiencia";
            this.txtExperiencia.Size = new System.Drawing.Size(196, 38);
            this.txtExperiencia.TabIndex = 26;
            // 
            // lbExperiencia
            // 
            this.lbExperiencia.AutoSize = true;
            this.lbExperiencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbExperiencia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbExperiencia.Location = new System.Drawing.Point(535, 325);
            this.lbExperiencia.Name = "lbExperiencia";
            this.lbExperiencia.Size = new System.Drawing.Size(210, 25);
            this.lbExperiencia.TabIndex = 25;
            this.lbExperiencia.Text = "Experiencia (años)";
            // 
            // txtCedula
            // 
            this.txtCedula.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.txtCedula.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCedula.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCedula.ForeColor = System.Drawing.Color.White;
            this.txtCedula.Location = new System.Drawing.Point(43, 186);
            this.txtCedula.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCedula.MaxLength = 20;
            this.txtCedula.Multiline = true;
            this.txtCedula.Name = "txtCedula";
            this.txtCedula.Size = new System.Drawing.Size(373, 38);
            this.txtCedula.TabIndex = 24;
            this.txtCedula.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtCedula_KeyPress);
            // 
            // lbCedula
            // 
            this.lbCedula.AutoSize = true;
            this.lbCedula.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCedula.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbCedula.Location = new System.Drawing.Point(38, 157);
            this.lbCedula.Name = "lbCedula";
            this.lbCedula.Size = new System.Drawing.Size(86, 25);
            this.lbCedula.TabIndex = 23;
            this.lbCedula.Text = "Cédula";
            // 
            // txtNombre
            // 
            this.txtNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.txtNombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre.ForeColor = System.Drawing.Color.White;
            this.txtNombre.Location = new System.Drawing.Point(38, 99);
            this.txtNombre.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtNombre.MaxLength = 100;
            this.txtNombre.Multiline = true;
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(727, 38);
            this.txtNombre.TabIndex = 22;
            this.txtNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtNombre_KeyPress);
            this.txtNombre.Leave += new System.EventHandler(this.TxtNombre_Leave);
            // 
            // lbNombre
            // 
            this.lbNombre.AutoSize = true;
            this.lbNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNombre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbNombre.Location = new System.Drawing.Point(38, 70);
            this.lbNombre.Name = "lbNombre";
            this.lbNombre.Size = new System.Drawing.Size(199, 25);
            this.lbNombre.TabIndex = 21;
            this.lbNombre.Text = "Nombre Completo";
            // 
            // lbDatosDelCandidato
            // 
            this.lbDatosDelCandidato.AutoSize = true;
            this.lbDatosDelCandidato.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDatosDelCandidato.ForeColor = System.Drawing.Color.White;
            this.lbDatosDelCandidato.Location = new System.Drawing.Point(33, 33);
            this.lbDatosDelCandidato.Name = "lbDatosDelCandidato";
            this.lbDatosDelCandidato.Size = new System.Drawing.Size(479, 26);
            this.lbDatosDelCandidato.TabIndex = 20;
            this.lbDatosDelCandidato.Text = "DATOS DEL CANDIDATO ENTREVISTADO";
            // 
            // lbTituloInformacionDelPuesto
            // 
            this.lbTituloInformacionDelPuesto.AutoSize = true;
            this.lbTituloInformacionDelPuesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTituloInformacionDelPuesto.ForeColor = System.Drawing.Color.White;
            this.lbTituloInformacionDelPuesto.Location = new System.Drawing.Point(46, 144);
            this.lbTituloInformacionDelPuesto.Name = "lbTituloInformacionDelPuesto";
            this.lbTituloInformacionDelPuesto.Size = new System.Drawing.Size(335, 26);
            this.lbTituloInformacionDelPuesto.TabIndex = 19;
            this.lbTituloInformacionDelPuesto.Text = "INFORMACION DEL PUESTO";
            // 
            // lbTituloEntrevistador
            // 
            this.lbTituloEntrevistador.AutoSize = true;
            this.lbTituloEntrevistador.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTituloEntrevistador.ForeColor = System.Drawing.Color.White;
            this.lbTituloEntrevistador.Location = new System.Drawing.Point(1427, 116);
            this.lbTituloEntrevistador.Name = "lbTituloEntrevistador";
            this.lbTituloEntrevistador.Size = new System.Drawing.Size(424, 26);
            this.lbTituloEntrevistador.TabIndex = 28;
            this.lbTituloEntrevistador.Text = "EVALUACIÓN DEL ENTREVISTADOR";
            // 
            // lbPresentacion
            // 
            this.lbPresentacion.AutoSize = true;
            this.lbPresentacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPresentacion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbPresentacion.Location = new System.Drawing.Point(1497, 164);
            this.lbPresentacion.Name = "lbPresentacion";
            this.lbPresentacion.Size = new System.Drawing.Size(248, 25);
            this.lbPresentacion.TabIndex = 29;
            this.lbPresentacion.Text = "Presentación personal";
            // 
            // lbComunicacion
            // 
            this.lbComunicacion.AutoSize = true;
            this.lbComunicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbComunicacion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbComunicacion.Location = new System.Drawing.Point(1497, 304);
            this.lbComunicacion.Name = "lbComunicacion";
            this.lbComunicacion.Size = new System.Drawing.Size(302, 25);
            this.lbComunicacion.TabIndex = 30;
            this.lbComunicacion.Text = "Comunicación y respuestas";
            // 
            // lbActitud
            // 
            this.lbActitud.AutoSize = true;
            this.lbActitud.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbActitud.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbActitud.Location = new System.Drawing.Point(1508, 461);
            this.lbActitud.Name = "lbActitud";
            this.lbActitud.Size = new System.Drawing.Size(92, 25);
            this.lbActitud.TabIndex = 31;
            this.lbActitud.Text = "Actitud ";
            // 
            // lbAspiracion
            // 
            this.lbAspiracion.AutoSize = true;
            this.lbAspiracion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAspiracion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbAspiracion.Location = new System.Drawing.Point(1508, 629);
            this.lbAspiracion.Name = "lbAspiracion";
            this.lbAspiracion.Size = new System.Drawing.Size(247, 25);
            this.lbAspiracion.TabIndex = 32;
            this.lbAspiracion.Text = "Aspiración profesional";
            // 
            // trbPresentacion
            // 
            this.trbPresentacion.Location = new System.Drawing.Point(1497, 201);
            this.trbPresentacion.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.trbPresentacion.Maximum = 5;
            this.trbPresentacion.Minimum = 1;
            this.trbPresentacion.Name = "trbPresentacion";
            this.trbPresentacion.Size = new System.Drawing.Size(341, 69);
            this.trbPresentacion.TabIndex = 33;
            this.trbPresentacion.Value = 1;
            // 
            // trbComunicacion
            // 
            this.trbComunicacion.Location = new System.Drawing.Point(1498, 350);
            this.trbComunicacion.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.trbComunicacion.Maximum = 5;
            this.trbComunicacion.Minimum = 1;
            this.trbComunicacion.Name = "trbComunicacion";
            this.trbComunicacion.Size = new System.Drawing.Size(340, 69);
            this.trbComunicacion.TabIndex = 34;
            this.trbComunicacion.Value = 1;
            // 
            // trbActitud
            // 
            this.trbActitud.Location = new System.Drawing.Point(1497, 506);
            this.trbActitud.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.trbActitud.Maximum = 5;
            this.trbActitud.Minimum = 1;
            this.trbActitud.Name = "trbActitud";
            this.trbActitud.Size = new System.Drawing.Size(341, 69);
            this.trbActitud.TabIndex = 35;
            this.trbActitud.Value = 1;
            // 
            // trbAspiracion
            // 
            this.trbAspiracion.Location = new System.Drawing.Point(1502, 669);
            this.trbAspiracion.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.trbAspiracion.Maximum = 5;
            this.trbAspiracion.Minimum = 1;
            this.trbAspiracion.Name = "trbAspiracion";
            this.trbAspiracion.Size = new System.Drawing.Size(336, 69);
            this.trbAspiracion.TabIndex = 36;
            this.trbAspiracion.Value = 1;
            // 
            // btGuardarEvaluacion
            // 
            this.btGuardarEvaluacion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(99)))), ((int)(((byte)(235)))));
            this.btGuardarEvaluacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btGuardarEvaluacion.ForeColor = System.Drawing.Color.White;
            this.btGuardarEvaluacion.Location = new System.Drawing.Point(1498, 873);
            this.btGuardarEvaluacion.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btGuardarEvaluacion.Name = "btGuardarEvaluacion";
            this.btGuardarEvaluacion.Size = new System.Drawing.Size(270, 55);
            this.btGuardarEvaluacion.TabIndex = 38;
            this.btGuardarEvaluacion.Text = "Guardar Evaluación";
            this.btGuardarEvaluacion.UseVisualStyleBackColor = false;
            this.btGuardarEvaluacion.Click += new System.EventHandler(this.BtGuardarEvaluacion_Click);
            // 
            // lbInformacion
            // 
            this.lbInformacion.AutoSize = true;
            this.lbInformacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbInformacion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbInformacion.Location = new System.Drawing.Point(46, 210);
            this.lbInformacion.Name = "lbInformacion";
            this.lbInformacion.Size = new System.Drawing.Size(0, 25);
            this.lbInformacion.TabIndex = 43;
            // 
            // btLimpiar
            // 
            this.btLimpiar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.btLimpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLimpiar.ForeColor = System.Drawing.Color.White;
            this.btLimpiar.Location = new System.Drawing.Point(1498, 785);
            this.btLimpiar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btLimpiar.Name = "btLimpiar";
            this.btLimpiar.Size = new System.Drawing.Size(270, 55);
            this.btLimpiar.TabIndex = 46;
            this.btLimpiar.Text = "Limpiar";
            this.btLimpiar.UseVisualStyleBackColor = false;
            this.btLimpiar.Click += new System.EventHandler(this.btLimpiar_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.ClientSize = new System.Drawing.Size(1969, 982);
            this.Controls.Add(this.btLimpiar);
            this.Controls.Add(this.lbInformacion);
            this.Controls.Add(this.btGuardarEvaluacion);
            this.Controls.Add(this.trbAspiracion);
            this.Controls.Add(this.trbActitud);
            this.Controls.Add(this.trbComunicacion);
            this.Controls.Add(this.trbPresentacion);
            this.Controls.Add(this.lbAspiracion);
            this.Controls.Add(this.lbActitud);
            this.Controls.Add(this.lbComunicacion);
            this.Controls.Add(this.lbPresentacion);
            this.Controls.Add(this.lbTituloEntrevistador);
            this.Controls.Add(this.lbTituloInformacionDelPuesto);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panEvaluarCandidatos);
            this.ForeColor = System.Drawing.SystemColors.GrayText;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form4";
            this.Text = "Evaluación de candidato";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form4_Load);
            this.panEvaluarCandidatos.ResumeLayout(false);
            this.panEvaluarCandidatos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAtras2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo5)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panSeleccionHabilidades.ResumeLayout(false);
            this.panSeleccionHabilidades.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trbPresentacion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trbComunicacion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trbActitud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trbAspiracion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panEvaluarCandidatos;
        private System.Windows.Forms.Label lbTituloEvaluarCandidato;
        private System.Windows.Forms.Label lbSphere5;
        private System.Windows.Forms.Label lbCode5;
        private System.Windows.Forms.PictureBox pbLogo5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbTituloInformacionDelPuesto;
        private System.Windows.Forms.Label lbDatosDelCandidato;
        private System.Windows.Forms.Label lbSeleccionHabilidades;
        private System.Windows.Forms.TextBox txtExperiencia;
        private System.Windows.Forms.Label lbExperiencia;
        private System.Windows.Forms.TextBox txtCedula;
        private System.Windows.Forms.Label lbCedula;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lbNombre;
        private System.Windows.Forms.Panel panSeleccionHabilidades;
        private System.Windows.Forms.CheckBox chHabilidad5;
        private System.Windows.Forms.CheckBox chHabilidad6;
        private System.Windows.Forms.CheckBox chHabilidad2;
        private System.Windows.Forms.CheckBox chHabilidad4;
        private System.Windows.Forms.CheckBox chHabilidad3;
        private System.Windows.Forms.CheckBox chHabilidad1;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.Label lbCorreo;
        private System.Windows.Forms.Label lbTituloEntrevistador;
        private System.Windows.Forms.Label lbPresentacion;
        private System.Windows.Forms.Label lbComunicacion;
        private System.Windows.Forms.Label lbActitud;
        private System.Windows.Forms.Label lbAspiracion;
        private System.Windows.Forms.TrackBar trbPresentacion;
        private System.Windows.Forms.TrackBar trbComunicacion;
        private System.Windows.Forms.TrackBar trbActitud;
        private System.Windows.Forms.TrackBar trbAspiracion;
        private System.Windows.Forms.Button btGuardarEvaluacion;
        private System.Windows.Forms.Label lbInformacion;
        private System.Windows.Forms.PictureBox pbAtras2;
        private System.Windows.Forms.Label lbNivelAcademico;
        private System.Windows.Forms.ComboBox cbNivelAcademico;
        private System.Windows.Forms.TextBox txtAspiracionSalario;
        private System.Windows.Forms.Label lbSalario;
        private System.Windows.Forms.Button btLimpiar;
    }
}