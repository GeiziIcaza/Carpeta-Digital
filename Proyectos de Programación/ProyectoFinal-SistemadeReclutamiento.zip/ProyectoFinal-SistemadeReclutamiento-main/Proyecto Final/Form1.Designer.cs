﻿namespace Proyecto_Final
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbCode1 = new System.Windows.Forms.Label();
            this.lbSphere1 = new System.Windows.Forms.Label();
            this.lbIniciarSesión = new System.Windows.Forms.Label();
            this.lbSistemadeReclutamiento = new System.Windows.Forms.Label();
            this.lbUsuario = new System.Windows.Forms.Label();
            this.lbTechnology1 = new System.Windows.Forms.Label();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.lbContrasenia = new System.Windows.Forms.Label();
            this.txtContrasenia = new System.Windows.Forms.TextBox();
            this.pbContrasenia = new System.Windows.Forms.PictureBox();
            this.pbUsuario = new System.Windows.Forms.PictureBox();
            this.pbLogo1 = new System.Windows.Forms.PictureBox();
            this.lbOlvidasteContrasenia = new System.Windows.Forms.Label();
            this.btIngresar = new System.Windows.Forms.Button();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pbContrasenia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUsuario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // lbCode1
            // 
            this.lbCode1.AutoSize = true;
            this.lbCode1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCode1.ForeColor = System.Drawing.Color.White;
            this.lbCode1.Location = new System.Drawing.Point(52, 295);
            this.lbCode1.Name = "lbCode1";
            this.lbCode1.Size = new System.Drawing.Size(90, 36);
            this.lbCode1.TabIndex = 0;
            this.lbCode1.Text = "Code";
            // 
            // lbSphere1
            // 
            this.lbSphere1.AutoSize = true;
            this.lbSphere1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSphere1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(189)))), ((int)(((byte)(248)))));
            this.lbSphere1.Location = new System.Drawing.Point(142, 295);
            this.lbSphere1.Name = "lbSphere1";
            this.lbSphere1.Size = new System.Drawing.Size(117, 36);
            this.lbSphere1.TabIndex = 3;
            this.lbSphere1.Text = "Sphere";
            // 
            // lbIniciarSesión
            // 
            this.lbIniciarSesión.AutoSize = true;
            this.lbIniciarSesión.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIniciarSesión.ForeColor = System.Drawing.Color.White;
            this.lbIniciarSesión.Location = new System.Drawing.Point(463, 39);
            this.lbIniciarSesión.Name = "lbIniciarSesión";
            this.lbIniciarSesión.Size = new System.Drawing.Size(204, 36);
            this.lbIniciarSesión.TabIndex = 4;
            this.lbIniciarSesión.Text = "Iniciar sesión";
            // 
            // lbSistemadeReclutamiento
            // 
            this.lbSistemadeReclutamiento.AutoSize = true;
            this.lbSistemadeReclutamiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSistemadeReclutamiento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbSistemadeReclutamiento.Location = new System.Drawing.Point(396, 84);
            this.lbSistemadeReclutamiento.Name = "lbSistemadeReclutamiento";
            this.lbSistemadeReclutamiento.Size = new System.Drawing.Size(336, 22);
            this.lbSistemadeReclutamiento.TabIndex = 5;
            this.lbSistemadeReclutamiento.Text = "Acceder al Sistema de reclutamiento";
            // 
            // lbUsuario
            // 
            this.lbUsuario.AutoSize = true;
            this.lbUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUsuario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbUsuario.Location = new System.Drawing.Point(361, 144);
            this.lbUsuario.Name = "lbUsuario";
            this.lbUsuario.Size = new System.Drawing.Size(79, 22);
            this.lbUsuario.TabIndex = 6;
            this.lbUsuario.Text = "Usuario";
            // 
            // lbTechnology1
            // 
            this.lbTechnology1.AutoSize = true;
            this.lbTechnology1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTechnology1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbTechnology1.Location = new System.Drawing.Point(75, 338);
            this.lbTechnology1.Name = "lbTechnology1";
            this.lbTechnology1.Size = new System.Drawing.Size(147, 22);
            this.lbTechnology1.TabIndex = 7;
            this.lbTechnology1.Text = "TECHNOLOGY";
            // 
            // txtUsuario
            // 
            this.txtUsuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.txtUsuario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuario.ForeColor = System.Drawing.Color.White;
            this.txtUsuario.Location = new System.Drawing.Point(406, 181);
            this.txtUsuario.MaxLength = 12;
            this.txtUsuario.Multiline = true;
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(348, 31);
            this.txtUsuario.TabIndex = 8;
            // 
            // lbContrasenia
            // 
            this.lbContrasenia.AutoSize = true;
            this.lbContrasenia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbContrasenia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbContrasenia.Location = new System.Drawing.Point(361, 250);
            this.lbContrasenia.Name = "lbContrasenia";
            this.lbContrasenia.Size = new System.Drawing.Size(113, 22);
            this.lbContrasenia.TabIndex = 10;
            this.lbContrasenia.Text = "Contraseña";
            // 
            // txtContrasenia
            // 
            this.txtContrasenia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.txtContrasenia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtContrasenia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContrasenia.ForeColor = System.Drawing.Color.White;
            this.txtContrasenia.Location = new System.Drawing.Point(406, 293);
            this.txtContrasenia.MaxLength = 20;
            this.txtContrasenia.Multiline = true;
            this.txtContrasenia.Name = "txtContrasenia";
            this.txtContrasenia.PasswordChar = '*';
            this.txtContrasenia.Size = new System.Drawing.Size(348, 31);
            this.txtContrasenia.TabIndex = 11;
            // 
            // pbContrasenia
            // 
            this.pbContrasenia.Image = global::Proyecto_Final.Properties.Resources.proteger;
            this.pbContrasenia.Location = new System.Drawing.Point(356, 286);
            this.pbContrasenia.Name = "pbContrasenia";
            this.pbContrasenia.Size = new System.Drawing.Size(41, 38);
            this.pbContrasenia.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbContrasenia.TabIndex = 12;
            this.pbContrasenia.TabStop = false;
            // 
            // pbUsuario
            // 
            this.pbUsuario.Image = global::Proyecto_Final.Properties.Resources.agregar_usuario__2_;
            this.pbUsuario.Location = new System.Drawing.Point(356, 178);
            this.pbUsuario.Name = "pbUsuario";
            this.pbUsuario.Size = new System.Drawing.Size(41, 38);
            this.pbUsuario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbUsuario.TabIndex = 9;
            this.pbUsuario.TabStop = false;
            // 
            // pbLogo1
            // 
            this.pbLogo1.Image = global::Proyecto_Final.Properties.Resources.Captura_de_pantalla_2026_07_11_163634;
            this.pbLogo1.Location = new System.Drawing.Point(55, 71);
            this.pbLogo1.Name = "pbLogo1";
            this.pbLogo1.Size = new System.Drawing.Size(201, 214);
            this.pbLogo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogo1.TabIndex = 2;
            this.pbLogo1.TabStop = false;
            // 
            // lbOlvidasteContrasenia
            // 
            this.lbOlvidasteContrasenia.AutoSize = true;
            this.lbOlvidasteContrasenia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOlvidasteContrasenia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(211)))), ((int)(((byte)(238)))));
            this.lbOlvidasteContrasenia.Location = new System.Drawing.Point(286, 449);
            this.lbOlvidasteContrasenia.Name = "lbOlvidasteContrasenia";
            this.lbOlvidasteContrasenia.Size = new System.Drawing.Size(244, 22);
            this.lbOlvidasteContrasenia.TabIndex = 13;
            this.lbOlvidasteContrasenia.Text = "¿Olvidaste tu contraseña?";
            this.lbOlvidasteContrasenia.Click += new System.EventHandler(this.LbOlvidasteContrasenia_Click);
            // 
            // btIngresar
            // 
            this.btIngresar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(99)))), ((int)(((byte)(235)))));
            this.btIngresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btIngresar.ForeColor = System.Drawing.Color.White;
            this.btIngresar.Location = new System.Drawing.Point(290, 386);
            this.btIngresar.Name = "btIngresar";
            this.btIngresar.Size = new System.Drawing.Size(240, 44);
            this.btIngresar.TabIndex = 14;
            this.btIngresar.Text = "Ingresar";
            this.btIngresar.UseVisualStyleBackColor = false;
            this.btIngresar.Click += new System.EventHandler(this.BtIngresar_Click);
            // 
            // errorProvider
            // 
            this.errorProvider.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errorProvider.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.ClientSize = new System.Drawing.Size(800, 508);
            this.Controls.Add(this.btIngresar);
            this.Controls.Add(this.lbOlvidasteContrasenia);
            this.Controls.Add(this.pbContrasenia);
            this.Controls.Add(this.txtContrasenia);
            this.Controls.Add(this.lbContrasenia);
            this.Controls.Add(this.pbUsuario);
            this.Controls.Add(this.txtUsuario);
            this.Controls.Add(this.lbTechnology1);
            this.Controls.Add(this.lbUsuario);
            this.Controls.Add(this.lbSistemadeReclutamiento);
            this.Controls.Add(this.lbIniciarSesión);
            this.Controls.Add(this.lbSphere1);
            this.Controls.Add(this.lbCode1);
            this.Controls.Add(this.pbLogo1);
            this.ForeColor = System.Drawing.Color.Gray;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Codesphere";
            ((System.ComponentModel.ISupportInitialize)(this.pbContrasenia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUsuario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbCode1;
        private System.Windows.Forms.PictureBox pbLogo1;
        private System.Windows.Forms.Label lbSphere1;
        private System.Windows.Forms.Label lbIniciarSesión;
        private System.Windows.Forms.Label lbSistemadeReclutamiento;
        private System.Windows.Forms.Label lbUsuario;
        private System.Windows.Forms.Label lbTechnology1;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.PictureBox pbUsuario;
        private System.Windows.Forms.Label lbContrasenia;
        private System.Windows.Forms.TextBox txtContrasenia;
        private System.Windows.Forms.PictureBox pbContrasenia;
        private System.Windows.Forms.Label lbOlvidasteContrasenia;
        private System.Windows.Forms.Button btIngresar;
        private System.Windows.Forms.ErrorProvider errorProvider;
    }
}

