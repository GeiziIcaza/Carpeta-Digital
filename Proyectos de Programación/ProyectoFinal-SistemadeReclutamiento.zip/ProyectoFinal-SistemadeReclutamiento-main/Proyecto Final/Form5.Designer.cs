﻿namespace Proyecto_Final
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panResultado = new System.Windows.Forms.Panel();
            this.pbAtras3 = new System.Windows.Forms.PictureBox();
            this.lbResultados = new System.Windows.Forms.Label();
            this.lbSphere6 = new System.Windows.Forms.Label();
            this.lbCode6 = new System.Windows.Forms.Label();
            this.pbLogo6 = new System.Windows.Forms.PictureBox();
            this.dataGridViewResultados = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbListaCandidatos = new System.Windows.Forms.Label();
            this.dataGridViewSeleccionados = new System.Windows.Forms.DataGridView();
            this.Columna1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Columna2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Columna3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Columna4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbCandidatosSeleccionados = new System.Windows.Forms.Label();
            this.panResultado.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAtras3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResultados)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSeleccionados)).BeginInit();
            this.SuspendLayout();
            // 
            // panResultado
            // 
            this.panResultado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.panResultado.Controls.Add(this.pbAtras3);
            this.panResultado.Controls.Add(this.lbResultados);
            this.panResultado.Controls.Add(this.lbSphere6);
            this.panResultado.Controls.Add(this.lbCode6);
            this.panResultado.Controls.Add(this.pbLogo6);
            this.panResultado.Location = new System.Drawing.Point(0, 0);
            this.panResultado.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panResultado.Name = "panResultado";
            this.panResultado.Size = new System.Drawing.Size(1947, 105);
            this.panResultado.TabIndex = 1;
            // 
            // pbAtras3
            // 
            this.pbAtras3.Image = global::Proyecto_Final.Properties.Resources.atras;
            this.pbAtras3.Location = new System.Drawing.Point(25, 15);
            this.pbAtras3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pbAtras3.Name = "pbAtras3";
            this.pbAtras3.Size = new System.Drawing.Size(118, 74);
            this.pbAtras3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbAtras3.TabIndex = 20;
            this.pbAtras3.TabStop = false;
            // 
            // lbResultados
            // 
            this.lbResultados.AutoSize = true;
            this.lbResultados.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResultados.ForeColor = System.Drawing.Color.White;
            this.lbResultados.Location = new System.Drawing.Point(150, 39);
            this.lbResultados.Name = "lbResultados";
            this.lbResultados.Size = new System.Drawing.Size(138, 26);
            this.lbResultados.TabIndex = 19;
            this.lbResultados.Text = "Resultados ";
            // 
            // lbSphere6
            // 
            this.lbSphere6.AutoSize = true;
            this.lbSphere6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSphere6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(189)))), ((int)(((byte)(248)))));
            this.lbSphere6.Location = new System.Drawing.Point(1415, 39);
            this.lbSphere6.Name = "lbSphere6";
            this.lbSphere6.Size = new System.Drawing.Size(98, 29);
            this.lbSphere6.TabIndex = 5;
            this.lbSphere6.Text = "Sphere";
            // 
            // lbCode6
            // 
            this.lbCode6.AutoSize = true;
            this.lbCode6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCode6.ForeColor = System.Drawing.Color.White;
            this.lbCode6.Location = new System.Drawing.Point(1503, 39);
            this.lbCode6.Name = "lbCode6";
            this.lbCode6.Size = new System.Drawing.Size(76, 29);
            this.lbCode6.TabIndex = 4;
            this.lbCode6.Text = "Code";
            // 
            // pbLogo6
            // 
            this.pbLogo6.Image = global::Proyecto_Final.Properties.Resources.Captura_de_pantalla_2026_07_11_163634;
            this.pbLogo6.Location = new System.Drawing.Point(1291, 13);
            this.pbLogo6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pbLogo6.Name = "pbLogo6";
            this.pbLogo6.Size = new System.Drawing.Size(118, 74);
            this.pbLogo6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogo6.TabIndex = 3;
            this.pbLogo6.TabStop = false;
            // 
            // dataGridViewResultados
            // 
            this.dataGridViewResultados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewResultados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.dataGridViewResultados.Location = new System.Drawing.Point(892, 192);
            this.dataGridViewResultados.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewResultados.Name = "dataGridViewResultados";
            this.dataGridViewResultados.RowHeadersWidth = 51;
            this.dataGridViewResultados.RowTemplate.Height = 24;
            this.dataGridViewResultados.Size = new System.Drawing.Size(763, 605);
            this.dataGridViewResultados.TabIndex = 2;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Column1";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.Width = 200;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Column2";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Width = 150;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Column3";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.Width = 150;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Column4";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            this.Column4.Width = 120;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Column5";
            this.Column5.MinimumWidth = 6;
            this.Column5.Name = "Column5";
            this.Column5.Width = 150;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Location = new System.Drawing.Point(0, 907);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1947, 105);
            this.panel4.TabIndex = 10;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.label11.Location = new System.Drawing.Point(540, 42);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(386, 25);
            this.label11.TabIndex = 6;
            this.label11.Text = "· Sistema de Selección de Personal";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(189)))), ((int)(((byte)(248)))));
            this.label9.Location = new System.Drawing.Point(441, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 29);
            this.label9.TabIndex = 5;
            this.label9.Text = "Sphere";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(370, 36);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 29);
            this.label10.TabIndex = 4;
            this.label10.Text = "Code";
            // 
            // lbListaCandidatos
            // 
            this.lbListaCandidatos.AutoSize = true;
            this.lbListaCandidatos.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbListaCandidatos.ForeColor = System.Drawing.Color.White;
            this.lbListaCandidatos.Location = new System.Drawing.Point(1103, 136);
            this.lbListaCandidatos.Name = "lbListaCandidatos";
            this.lbListaCandidatos.Size = new System.Drawing.Size(306, 39);
            this.lbListaCandidatos.TabIndex = 11;
            this.lbListaCandidatos.Text = "Candidatos Evaluados";
            // 
            // dataGridViewSeleccionados
            // 
            this.dataGridViewSeleccionados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSeleccionados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Columna1,
            this.Columna2,
            this.Columna3,
            this.Columna4});
            this.dataGridViewSeleccionados.Location = new System.Drawing.Point(124, 192);
            this.dataGridViewSeleccionados.Name = "dataGridViewSeleccionados";
            this.dataGridViewSeleccionados.RowHeadersWidth = 62;
            this.dataGridViewSeleccionados.RowTemplate.Height = 28;
            this.dataGridViewSeleccionados.Size = new System.Drawing.Size(660, 605);
            this.dataGridViewSeleccionados.TabIndex = 12;
            // 
            // Columna1
            // 
            this.Columna1.HeaderText = "Columna1";
            this.Columna1.MinimumWidth = 8;
            this.Columna1.Name = "Columna1";
            this.Columna1.ReadOnly = true;
            this.Columna1.Width = 150;
            // 
            // Columna2
            // 
            this.Columna2.HeaderText = "Columna2";
            this.Columna2.MinimumWidth = 8;
            this.Columna2.Name = "Columna2";
            this.Columna2.ReadOnly = true;
            this.Columna2.Width = 150;
            // 
            // Columna3
            // 
            this.Columna3.HeaderText = "Columna3";
            this.Columna3.MinimumWidth = 8;
            this.Columna3.Name = "Columna3";
            this.Columna3.ReadOnly = true;
            this.Columna3.Width = 200;
            // 
            // Columna4
            // 
            this.Columna4.HeaderText = "Columna4";
            this.Columna4.MinimumWidth = 8;
            this.Columna4.Name = "Columna4";
            this.Columna4.ReadOnly = true;
            this.Columna4.Width = 150;
            // 
            // lbCandidatosSeleccionados
            // 
            this.lbCandidatosSeleccionados.AutoSize = true;
            this.lbCandidatosSeleccionados.Font = new System.Drawing.Font("Impact", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCandidatosSeleccionados.ForeColor = System.Drawing.Color.White;
            this.lbCandidatosSeleccionados.Location = new System.Drawing.Point(222, 136);
            this.lbCandidatosSeleccionados.Name = "lbCandidatosSeleccionados";
            this.lbCandidatosSeleccionados.Size = new System.Drawing.Size(367, 39);
            this.lbCandidatosSeleccionados.TabIndex = 13;
            this.lbCandidatosSeleccionados.Text = "Candidatos Seleccionados";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.ClientSize = new System.Drawing.Size(1793, 1017);
            this.Controls.Add(this.lbCandidatosSeleccionados);
            this.Controls.Add(this.dataGridViewSeleccionados);
            this.Controls.Add(this.lbListaCandidatos);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.dataGridViewResultados);
            this.Controls.Add(this.panResultado);
            this.ForeColor = System.Drawing.SystemColors.GrayText;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form5";
            this.Text = "Resultados de evaluaciones";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panResultado.ResumeLayout(false);
            this.panResultado.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAtras3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResultados)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSeleccionados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panResultado;
        private System.Windows.Forms.Label lbSphere6;
        private System.Windows.Forms.Label lbCode6;
        private System.Windows.Forms.PictureBox pbLogo6;
        private System.Windows.Forms.PictureBox pbAtras3;
        private System.Windows.Forms.Label lbResultados;
        private System.Windows.Forms.DataGridView dataGridViewResultados;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbListaCandidatos;
        private System.Windows.Forms.DataGridView dataGridViewSeleccionados;
        private System.Windows.Forms.Label lbCandidatosSeleccionados;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Columna1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Columna2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Columna3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Columna4;
    }
}