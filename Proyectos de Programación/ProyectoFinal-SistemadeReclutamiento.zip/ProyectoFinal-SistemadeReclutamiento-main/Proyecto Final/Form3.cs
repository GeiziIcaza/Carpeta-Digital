﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Final
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            txtSeccion.Text = Form1.departamentoUsuario;
            txtSeccion.ReadOnly = true;

            // Cargar puestos según departamento
            Vacante vacante = new Vacante();
            string[] puestos =vacante.ObtenerPuestos(Form1.departamentoUsuario);
            cbPuesto.Items.Clear();

            for (int i = 0; i < puestos.Length; i++)
            {
                cbPuesto.Items.Add(puestos[i]);
            }
        }


        // Obtener las habilidades correspondientes al puesto seleccionado
        private void CbPuesto_SelectedIndexChanged(object sender, EventArgs e)
        {
            Vacante vacante = new Vacante();
            vacante.AsignarHabilidades(cbPuesto.Text);
            lbHabilidades.Text = "";
            for (int i = 0; i < vacante.HabilidadesRequeridas.Length; i++)
            {
                lbHabilidades.Text +=
                "• " + vacante.HabilidadesRequeridas[i] + "\n";
            }
        }

        private void BtGuardarVacante_Click(object sender, EventArgs e)
        {
            try
            {
                // Validaciones
                if (cbPuesto.SelectedIndex == -1)
                {
                    MessageBox.Show("Seleccione un puesto.");
                    return;
                }

                if (txtExperienciaSolicitada.Text.Trim() == "")
                {
                    MessageBox.Show("Ingrese los años de experiencia.");
                    txtExperienciaSolicitada.Focus();
                    return;
                }

                int experiencia;
                if (!int.TryParse(txtExperienciaSolicitada.Text, out experiencia))
                {
                    MessageBox.Show("La experiencia debe ser un número.");
                    txtExperienciaSolicitada.Focus();
                    return;
                }

                if (experiencia < 0)
                {
                    MessageBox.Show("La experiencia no puede ser negativa.");
                    txtExperienciaSolicitada.Focus();
                    return;
                }
                
                if (txtSalario.Text.Trim() == "")
                {
                    MessageBox.Show("Ingrese el salario de la vacante.");
                    txtSalario.Focus();
                    return;
                }

                double salario;

                if (!double.TryParse(txtSalario.Text, out salario))
                {
                    MessageBox.Show("El salario debe ser un número.");
                    txtSalario.Focus();
                    return;
                }

                if (salario <= 0)
                {
                    MessageBox.Show("El salario debe ser mayor que cero.");
                    txtSalario.Focus();
                    return;
                }

                if (cbNivelAcademico.SelectedIndex == -1)
                {
                    MessageBox.Show("Seleccione el nivel académico.");
                    cbNivelAcademico.Focus();
                    return;
                }
                if (numPlazas.Value <= 0)
                {
                    MessageBox.Show("La cantidad de plazas debe ser mayor que cero.");
                    numPlazas.Focus();
                    return;
                }
                // Crear objeto Vacante
                Vacante nuevaVacante = new Vacante();
                nuevaVacante.NombrePuesto = cbPuesto.Text;
                nuevaVacante.Departamento = txtSeccion.Text;
                nuevaVacante.Experiencia = experiencia;
                nuevaVacante.Salario =Convert.ToDouble(txtSalario.Text);
                nuevaVacante.NivelAcademico = cbNivelAcademico.Text;
                nuevaVacante.CantidadPlazas =Convert.ToInt32(numPlazas.Value);
                nuevaVacante.AsignarHabilidades(cbPuesto.Text);

                // Guardar en el arreglo
                bool guardado = Form1.evaluacion.AgregarVacante(nuevaVacante);

                if (guardado)
                {
                    MessageBox.Show(
                    "Vacante guardada correctamente.",
                    "Sistema RRHH",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                    Limpiar();
                    this.Close();
                }
                else
                {
                    MessageBox.Show( "No se pueden agregar más vacantes para este puesto.");
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(
                error.Message,
                "Error");
            }

        }

        private void BtLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }
        private void Limpiar()
        {
            cbPuesto.SelectedIndex = -1;
            cbNivelAcademico.SelectedIndex = -1;
            numPlazas.Value = 1;
            txtSalario.Clear();
            txtExperienciaSolicitada.Clear();
            lbHabilidades.Text = "";
        }
        private void PbAtras1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
    
