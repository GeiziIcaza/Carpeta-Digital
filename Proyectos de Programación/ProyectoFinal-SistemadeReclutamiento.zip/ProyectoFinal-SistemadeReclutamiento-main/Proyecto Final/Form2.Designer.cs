﻿namespace Proyecto_Final
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbSphere2 = new System.Windows.Forms.Label();
            this.lbCode2 = new System.Windows.Forms.Label();
            this.pbLogo2 = new System.Windows.Forms.PictureBox();
            this.lbPanel = new System.Windows.Forms.Label();
            this.lbOpcion = new System.Windows.Forms.Label();
            this.panVacante = new System.Windows.Forms.Panel();
            this.pbVacante = new System.Windows.Forms.PictureBox();
            this.btNuevaVacante = new System.Windows.Forms.Button();
            this.lbDefineElPuesto = new System.Windows.Forms.Label();
            this.lbCrearSolicitudDeVacante = new System.Windows.Forms.Label();
            this.panCandidato = new System.Windows.Forms.Panel();
            this.btRegistrar = new System.Windows.Forms.Button();
            this.cbVacantes = new System.Windows.Forms.ComboBox();
            this.pbCandidato = new System.Windows.Forms.PictureBox();
            this.btEvaluaciones = new System.Windows.Forms.Button();
            this.lbSeleccionarVacante = new System.Windows.Forms.Label();
            this.lbEvaluar = new System.Windows.Forms.Label();
            this.panSistemaDeSeleccion = new System.Windows.Forms.Panel();
            this.lbSistemaDeSeleccion = new System.Windows.Forms.Label();
            this.lbSphere3 = new System.Windows.Forms.Label();
            this.lbCode3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo2)).BeginInit();
            this.panVacante.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbVacante)).BeginInit();
            this.panCandidato.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCandidato)).BeginInit();
            this.panSistemaDeSeleccion.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.panel1.Controls.Add(this.lbSphere2);
            this.panel1.Controls.Add(this.lbCode2);
            this.panel1.Controls.Add(this.pbLogo2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(966, 117);
            this.panel1.TabIndex = 0;
            // 
            // lbSphere2
            // 
            this.lbSphere2.AutoSize = true;
            this.lbSphere2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSphere2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(189)))), ((int)(((byte)(248)))));
            this.lbSphere2.Location = new System.Drawing.Point(205, 36);
            this.lbSphere2.Name = "lbSphere2";
            this.lbSphere2.Size = new System.Drawing.Size(98, 29);
            this.lbSphere2.TabIndex = 5;
            this.lbSphere2.Text = "Sphere";
            // 
            // lbCode2
            // 
            this.lbCode2.AutoSize = true;
            this.lbCode2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCode2.ForeColor = System.Drawing.Color.White;
            this.lbCode2.Location = new System.Drawing.Point(134, 36);
            this.lbCode2.Name = "lbCode2";
            this.lbCode2.Size = new System.Drawing.Size(90, 29);
            this.lbCode2.TabIndex = 4;
            this.lbCode2.Text = "Code2";
            // 
            // pbLogo2
            // 
            this.pbLogo2.Image = global::Proyecto_Final.Properties.Resources.Captura_de_pantalla_2026_07_11_163634;
            this.pbLogo2.Location = new System.Drawing.Point(14, 15);
            this.pbLogo2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pbLogo2.Name = "pbLogo2";
            this.pbLogo2.Size = new System.Drawing.Size(118, 74);
            this.pbLogo2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogo2.TabIndex = 3;
            this.pbLogo2.TabStop = false;
            // 
            // lbPanel
            // 
            this.lbPanel.AutoSize = true;
            this.lbPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPanel.ForeColor = System.Drawing.Color.White;
            this.lbPanel.Location = new System.Drawing.Point(253, 142);
            this.lbPanel.Name = "lbPanel";
            this.lbPanel.Size = new System.Drawing.Size(448, 32);
            this.lbPanel.TabIndex = 5;
            this.lbPanel.Text = "Panel de Selección de Personal";
            // 
            // lbOpcion
            // 
            this.lbOpcion.AutoSize = true;
            this.lbOpcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOpcion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbOpcion.Location = new System.Drawing.Point(284, 191);
            this.lbOpcion.Name = "lbOpcion";
            this.lbOpcion.Size = new System.Drawing.Size(411, 26);
            this.lbOpcion.TabIndex = 6;
            this.lbOpcion.Text = "Selecciona una opción para continuar";
            // 
            // panVacante
            // 
            this.panVacante.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.panVacante.Controls.Add(this.pbVacante);
            this.panVacante.Controls.Add(this.btNuevaVacante);
            this.panVacante.Controls.Add(this.lbDefineElPuesto);
            this.panVacante.Controls.Add(this.lbCrearSolicitudDeVacante);
            this.panVacante.Location = new System.Drawing.Point(73, 269);
            this.panVacante.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panVacante.Name = "panVacante";
            this.panVacante.Size = new System.Drawing.Size(353, 425);
            this.panVacante.TabIndex = 7;
            // 
            // pbVacante
            // 
            this.pbVacante.Image = global::Proyecto_Final.Properties.Resources.aprobar;
            this.pbVacante.Location = new System.Drawing.Point(106, 34);
            this.pbVacante.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pbVacante.Name = "pbVacante";
            this.pbVacante.Size = new System.Drawing.Size(118, 74);
            this.pbVacante.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbVacante.TabIndex = 16;
            this.pbVacante.TabStop = false;
            // 
            // btNuevaVacante
            // 
            this.btNuevaVacante.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(99)))), ((int)(((byte)(235)))));
            this.btNuevaVacante.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNuevaVacante.ForeColor = System.Drawing.Color.White;
            this.btNuevaVacante.Location = new System.Drawing.Point(37, 286);
            this.btNuevaVacante.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btNuevaVacante.Name = "btNuevaVacante";
            this.btNuevaVacante.Size = new System.Drawing.Size(270, 55);
            this.btNuevaVacante.TabIndex = 15;
            this.btNuevaVacante.Text = "Nueva vacante →";
            this.btNuevaVacante.UseVisualStyleBackColor = false;
            this.btNuevaVacante.Click += new System.EventHandler(this.BtNuevaVacante_Click);
            // 
            // lbDefineElPuesto
            // 
            this.lbDefineElPuesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDefineElPuesto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbDefineElPuesto.Location = new System.Drawing.Point(3, 159);
            this.lbDefineElPuesto.Name = "lbDefineElPuesto";
            this.lbDefineElPuesto.Size = new System.Drawing.Size(346, 64);
            this.lbDefineElPuesto.TabIndex = 7;
            this.lbDefineElPuesto.Text = "Define el puesto, requisitos y habilidades necesarias";
            this.lbDefineElPuesto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbCrearSolicitudDeVacante
            // 
            this.lbCrearSolicitudDeVacante.AutoSize = true;
            this.lbCrearSolicitudDeVacante.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCrearSolicitudDeVacante.ForeColor = System.Drawing.Color.White;
            this.lbCrearSolicitudDeVacante.Location = new System.Drawing.Point(33, 131);
            this.lbCrearSolicitudDeVacante.Name = "lbCrearSolicitudDeVacante";
            this.lbCrearSolicitudDeVacante.Size = new System.Drawing.Size(297, 26);
            this.lbCrearSolicitudDeVacante.TabIndex = 6;
            this.lbCrearSolicitudDeVacante.Text = "Crear Solicitud de Vacante";
            // 
            // panCandidato
            // 
            this.panCandidato.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.panCandidato.Controls.Add(this.btRegistrar);
            this.panCandidato.Controls.Add(this.cbVacantes);
            this.panCandidato.Controls.Add(this.pbCandidato);
            this.panCandidato.Controls.Add(this.btEvaluaciones);
            this.panCandidato.Controls.Add(this.lbSeleccionarVacante);
            this.panCandidato.Controls.Add(this.lbEvaluar);
            this.panCandidato.Location = new System.Drawing.Point(531, 269);
            this.panCandidato.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panCandidato.Name = "panCandidato";
            this.panCandidato.Size = new System.Drawing.Size(353, 425);
            this.panCandidato.TabIndex = 8;
            // 
            // btRegistrar
            // 
            this.btRegistrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(99)))), ((int)(((byte)(235)))));
            this.btRegistrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btRegistrar.ForeColor = System.Drawing.Color.White;
            this.btRegistrar.Location = new System.Drawing.Point(39, 286);
            this.btRegistrar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btRegistrar.Name = "btRegistrar";
            this.btRegistrar.Size = new System.Drawing.Size(270, 55);
            this.btRegistrar.TabIndex = 22;
            this.btRegistrar.Text = "Registrar→";
            this.btRegistrar.UseVisualStyleBackColor = false;
            this.btRegistrar.Click += new System.EventHandler(this.BtRegistrar_Click);
            // 
            // cbVacantes
            // 
            this.cbVacantes.BackColor = System.Drawing.Color.White;
            this.cbVacantes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbVacantes.ForeColor = System.Drawing.Color.Black;
            this.cbVacantes.FormattingEnabled = true;
            this.cbVacantes.Location = new System.Drawing.Point(46, 242);
            this.cbVacantes.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbVacantes.Name = "cbVacantes";
            this.cbVacantes.Size = new System.Drawing.Size(266, 28);
            this.cbVacantes.TabIndex = 21;
            // 
            // pbCandidato
            // 
            this.pbCandidato.Image = global::Proyecto_Final.Properties.Resources.lista_de_verificacion;
            this.pbCandidato.Location = new System.Drawing.Point(118, 34);
            this.pbCandidato.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pbCandidato.Name = "pbCandidato";
            this.pbCandidato.Size = new System.Drawing.Size(118, 74);
            this.pbCandidato.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCandidato.TabIndex = 19;
            this.pbCandidato.TabStop = false;
            // 
            // btEvaluaciones
            // 
            this.btEvaluaciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.btEvaluaciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btEvaluaciones.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(189)))), ((int)(((byte)(248)))));
            this.btEvaluaciones.Location = new System.Drawing.Point(42, 353);
            this.btEvaluaciones.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btEvaluaciones.Name = "btEvaluaciones";
            this.btEvaluaciones.Size = new System.Drawing.Size(267, 55);
            this.btEvaluaciones.TabIndex = 18;
            this.btEvaluaciones.Text = "Ver Evaluaciones →";
            this.btEvaluaciones.UseVisualStyleBackColor = false;
            this.btEvaluaciones.Click += new System.EventHandler(this.BtSolicitudes_Click);
            // 
            // lbSeleccionarVacante
            // 
            this.lbSeleccionarVacante.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSeleccionarVacante.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbSeleccionarVacante.Location = new System.Drawing.Point(7, 159);
            this.lbSeleccionarVacante.Name = "lbSeleccionarVacante";
            this.lbSeleccionarVacante.Size = new System.Drawing.Size(343, 64);
            this.lbSeleccionarVacante.TabIndex = 17;
            this.lbSeleccionarVacante.Text = "Selecciona una vacante y registra los datos del candidato entrevistado";
            this.lbSeleccionarVacante.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbEvaluar
            // 
            this.lbEvaluar.AutoSize = true;
            this.lbEvaluar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEvaluar.ForeColor = System.Drawing.Color.White;
            this.lbEvaluar.Location = new System.Drawing.Point(66, 131);
            this.lbEvaluar.Name = "lbEvaluar";
            this.lbEvaluar.Size = new System.Drawing.Size(220, 26);
            this.lbEvaluar.TabIndex = 16;
            this.lbEvaluar.Text = "Evaluar Candidatos";
            // 
            // panSistemaDeSeleccion
            // 
            this.panSistemaDeSeleccion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.panSistemaDeSeleccion.Controls.Add(this.lbSistemaDeSeleccion);
            this.panSistemaDeSeleccion.Controls.Add(this.lbSphere3);
            this.panSistemaDeSeleccion.Controls.Add(this.lbCode3);
            this.panSistemaDeSeleccion.Location = new System.Drawing.Point(0, 754);
            this.panSistemaDeSeleccion.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panSistemaDeSeleccion.Name = "panSistemaDeSeleccion";
            this.panSistemaDeSeleccion.Size = new System.Drawing.Size(966, 105);
            this.panSistemaDeSeleccion.TabIndex = 9;
            // 
            // lbSistemaDeSeleccion
            // 
            this.lbSistemaDeSeleccion.AutoSize = true;
            this.lbSistemaDeSeleccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSistemaDeSeleccion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbSistemaDeSeleccion.Location = new System.Drawing.Point(436, 42);
            this.lbSistemaDeSeleccion.Name = "lbSistemaDeSeleccion";
            this.lbSistemaDeSeleccion.Size = new System.Drawing.Size(386, 25);
            this.lbSistemaDeSeleccion.TabIndex = 6;
            this.lbSistemaDeSeleccion.Text = "· Sistema de Selección de Personal";
            // 
            // lbSphere3
            // 
            this.lbSphere3.AutoSize = true;
            this.lbSphere3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSphere3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(189)))), ((int)(((byte)(248)))));
            this.lbSphere3.Location = new System.Drawing.Point(338, 36);
            this.lbSphere3.Name = "lbSphere3";
            this.lbSphere3.Size = new System.Drawing.Size(98, 29);
            this.lbSphere3.TabIndex = 5;
            this.lbSphere3.Text = "Sphere";
            // 
            // lbCode3
            // 
            this.lbCode3.AutoSize = true;
            this.lbCode3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCode3.ForeColor = System.Drawing.Color.White;
            this.lbCode3.Location = new System.Drawing.Point(267, 36);
            this.lbCode3.Name = "lbCode3";
            this.lbCode3.Size = new System.Drawing.Size(76, 29);
            this.lbCode3.TabIndex = 4;
            this.lbCode3.Text = "Code";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.ClientSize = new System.Drawing.Size(966, 858);
            this.Controls.Add(this.panSistemaDeSeleccion);
            this.Controls.Add(this.panCandidato);
            this.Controls.Add(this.panVacante);
            this.Controls.Add(this.lbOpcion);
            this.Controls.Add(this.lbPanel);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.GrayText;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.Text = "Menú Principal";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo2)).EndInit();
            this.panVacante.ResumeLayout(false);
            this.panVacante.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbVacante)).EndInit();
            this.panCandidato.ResumeLayout(false);
            this.panCandidato.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCandidato)).EndInit();
            this.panSistemaDeSeleccion.ResumeLayout(false);
            this.panSistemaDeSeleccion.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pbLogo2;
        private System.Windows.Forms.Label lbSphere2;
        private System.Windows.Forms.Label lbCode2;
        private System.Windows.Forms.Label lbPanel;
        private System.Windows.Forms.Label lbOpcion;
        private System.Windows.Forms.Panel panVacante;
        private System.Windows.Forms.Panel panCandidato;
        private System.Windows.Forms.Label lbDefineElPuesto;
        private System.Windows.Forms.Label lbCrearSolicitudDeVacante;
        private System.Windows.Forms.Button btNuevaVacante;
        private System.Windows.Forms.Button btEvaluaciones;
        private System.Windows.Forms.Label lbSeleccionarVacante;
        private System.Windows.Forms.Label lbEvaluar;
        private System.Windows.Forms.PictureBox pbVacante;
        private System.Windows.Forms.PictureBox pbCandidato;
        private System.Windows.Forms.Panel panSistemaDeSeleccion;
        private System.Windows.Forms.Label lbSistemaDeSeleccion;
        private System.Windows.Forms.Label lbSphere3;
        private System.Windows.Forms.Label lbCode3;
        private System.Windows.Forms.ComboBox cbVacantes;
        private System.Windows.Forms.Button btRegistrar;
    }
}