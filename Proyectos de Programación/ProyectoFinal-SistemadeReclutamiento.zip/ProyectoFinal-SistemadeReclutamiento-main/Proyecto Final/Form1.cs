﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Final
{
    public partial class Form1 : Form
    {
        public static Evaluacion evaluacion = new Evaluacion();
        public static string departamentoUsuario;
        Usuario usuario = new Usuario();
        public Form1()
        {
            InitializeComponent();
        }

        private void BtIngresar_Click(object sender, EventArgs e)
        {
            errorProvider.Clear();
            bool correcto = true;

            if (txtUsuario.Text.Trim() == "")
            {
                errorProvider.SetError(txtUsuario, "Ingrese usuario");
                correcto = false;
            }

            if (txtContrasenia.Text.Trim() == "")
            {
                errorProvider.SetError(txtContrasenia, "Ingrese contraseña");
                correcto = false;
            }


            if (correcto)
            {

                if (usuario.ValidarUsuario(txtUsuario.Text, txtContrasenia.Text))
                {
                    Form1.departamentoUsuario =
                    usuario.ObtenerDepartamento(txtUsuario.Text);
                    Form2 formulario = new Form2();
                    formulario.Show();
                    this.Hide();
                }
                else
                {

                    MessageBox.Show(
                    "Usuario o contraseña incorrectos",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                    //Limpiar automaticamente el usuario y la contraseña
                    txtUsuario.Clear();
                    txtUsuario.Focus();
                    txtContrasenia.Clear();
                    txtContrasenia.Focus();
                }

            }

        }
       
        private void LbOlvidasteContrasenia_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
            "Si olvidaste tu contraseña, " +
            "comunícate con el departamento de Soporte Técnico enviando un correo a soportetecnico@codesphere.com." +
            " Nuestro equipo verificará tu información y te ayudará a restablecer el acceso a tu cuenta.",
            "Recuperar contraseña");
        }

    }
}




