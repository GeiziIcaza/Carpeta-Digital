﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Final
{
    public class Evaluacion
    {

        private Vacante[] vacantes;
        private Candidato[] candidatos;

        private int contadorVacantes;
        private int contadorCandidatos;


        public Evaluacion()
        {
            vacantes = new Vacante[100];
            candidatos = new Candidato[300];

            contadorVacantes = 0;
            contadorCandidatos = 0;
        }

        // Agregar una nueva vacante
        public bool AgregarVacante(Vacante vacante)
        {

            for (int i = 0; i < contadorVacantes; i++)
            {
                if (vacantes[i].NombrePuesto.Equals(vacante.NombrePuesto))
                {
                    return false;
                }
            }

            if (contadorVacantes < vacantes.Length)
            {
                vacantes[contadorVacantes] = vacante;
                contadorVacantes++;

                return true;
            }

            return false;
        }

        // Buscar una vacante por nombre
        public Vacante BuscarVacante(string nombrePuesto)
        {

            for (int i = 0; i < contadorVacantes; i++)
            {

                if (vacantes[i].NombrePuesto.Equals(nombrePuesto))
                {
                    return vacantes[i];
                }

            }

            return null;
        }

        // Obtener las vacantes para llenar ComboBox
        public Vacante[] ObtenerVacantes()
        {
            return vacantes;
        }

        public int CantidadVacantes()
        {
            return contadorVacantes;
        }

        // Agregar un nuevo candidato evaluado
        public bool AgregarCandidato(Candidato candidato)
        {

            if (contadorCandidatos < candidatos.Length)
            {
                candidatos[contadorCandidatos] = candidato;
                contadorCandidatos++;

                return true;
            }

            return false;
        }

        //Evitar Candidato Repetido
        public bool EvitarRepetirCedula(string cedula)
        {
            for (int i = 0; i < contadorCandidatos; i++)
            {
                if (candidatos[i].Cedula == cedula)
                {
                    return true;
                }
            }

            return false;
        }

        // Obtener los candidatos para llenar el DataGridView
        public Candidato[] ObtenerCandidatos()
        {
            return candidatos;
        }

        public int CantidadCandidatos()
        {
            return contadorCandidatos;
        }

        public Candidato[] ObtenerSeleccionados(Vacante vacante)
        {
            Candidato[] seleccionados = new Candidato[vacante.CantidadPlazas];
            Candidato[] candidatosVacante = new Candidato[contadorCandidatos];
            int contador = 0;

            // Buscar candidatos de la vacante
            for (int i = 0; i < contadorCandidatos; i++)
            {
                if (candidatos[i].Vacante == vacante.NombrePuesto)
                {
                    candidatosVacante[contador] = candidatos[i];
                    contador++;
                }
            }

            // Ordenar por puntaje (mayor a menor), con desempate:
            // 1) Puntaje total  2) Puntaje de habilidades  3) Experiencia  4) Puntaje de entrevista
            for (int i = 0; i < contador - 1; i++)
            {
                for (int j = 0; j < contador - i - 1; j++)
                {
                    if (DebeIntercambiar(candidatosVacante[j], candidatosVacante[j + 1]))
                    {
                        Candidato aux = candidatosVacante[j];
                        candidatosVacante[j] = candidatosVacante[j + 1];
                        candidatosVacante[j + 1] = aux;
                    }
                }
            }

            // Tomar los mejores según las plazas
            int cantidad = vacante.CantidadPlazas;

            if (cantidad > contador)
            {
                cantidad = contador;
            }

            for (int i = 0; i < cantidad; i++)
            {
                seleccionados[i] = candidatosVacante[i];
            }
            return seleccionados;
        }

        // Decide si "actual" debe pasar antes que "siguiente" en el orden.
        // Compara primero el puntaje total; si hay empate, desempata con
        // criterios cada vez más específicos: habilidades, experiencia,
        // y por último la evaluación de la entrevista.
        private bool DebeIntercambiar(Candidato actual, Candidato siguiente)
        {
            if (actual.Puntaje != siguiente.Puntaje)
            {
                return actual.Puntaje < siguiente.Puntaje;
            }

            if (actual.PuntajeHabilidades != siguiente.PuntajeHabilidades)
            {
                return actual.PuntajeHabilidades < siguiente.PuntajeHabilidades;
            }

            if (actual.Experiencia != siguiente.Experiencia)
            {
                return actual.Experiencia < siguiente.Experiencia;
            }

            return actual.PuntajeEntrevista < siguiente.PuntajeEntrevista;
        }
    }
}