﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Final
{
    public class Vacante
    {
        private string nombrePuesto;
        private string departamento;
        private double salario;
        private int experiencia;
        private string nivelAcademico;
        private int cantidadPlazas;

        private string[] habilidadesRequeridas;
        private string[] habilidadesExtras;

        public Vacante()
        {
            habilidadesRequeridas = new string[4];
            habilidadesExtras = new string[2];
        }
        public string NombrePuesto
        {
            get { return nombrePuesto; }
            set { nombrePuesto = value; }
        }
        public string Departamento
        {
            get { return departamento; }
            set { departamento = value; }
        }

        public double Salario
        {
            get { return salario; }
            set { salario = value; }
        }

        public int Experiencia
        {
            get { return experiencia; }
            set { experiencia = value; }
        }

        public string NivelAcademico
        {
            get { return nivelAcademico; }
            set { nivelAcademico = value; }
        }
        public int CantidadPlazas
        {
            get { return cantidadPlazas; }
            set { cantidadPlazas = value; }
        }
        public string[] HabilidadesRequeridas
        {
            get { return habilidadesRequeridas; }
        }

        public string[] HabilidadesExtras
        {
            get { return habilidadesExtras; }
        }

        // Asignación de información según el puesto
        public void AsignarHabilidades(string puesto)
        {
            for (int i = 0; i < habilidadesRequeridas.Length; i++)
            {
                habilidadesRequeridas[i] = "";
            }

            for (int i = 0; i < habilidadesExtras.Length; i++)
            {
                habilidadesExtras[i] = "";
            }

            switch (puesto)
            {
                // Recursos Humanos
                case "Asistente de Recursos Humanos":

                    habilidadesRequeridas[0] = "Comunicación efectiva";
                    habilidadesRequeridas[1] = "Microsoft Excel";
                    habilidadesRequeridas[2] = "Organización documental";
                    habilidadesRequeridas[3] = "Atención al cliente";
                    habilidadesExtras[0] = "Inglés";
                    habilidadesExtras[1] = "Power BI";

                    break;

                case "Analista de Recursos Humanos":

                    habilidadesRequeridas[0] = "Reclutamiento y selección";
                    habilidadesRequeridas[1] = "Entrevistas por competencias";
                    habilidadesRequeridas[2] = "Excel avanzado";
                    habilidadesRequeridas[3] = "Legislación laboral";
                    habilidadesExtras[0] = "Power BI";
                    habilidadesExtras[1] = "Inglés";

                    break;

                case "Jefe de Recursos Humanos":

                    habilidadesRequeridas[0] = "Liderazgo";
                    habilidadesRequeridas[1] = "Gestión del talento";
                    habilidadesRequeridas[2] = "Planificación estratégica";
                    habilidadesRequeridas[3] = "Resolución de conflictos";
                    habilidadesExtras[0] = "Negociación";
                    habilidadesExtras[1] = "Inglés";

                    break;

                // Desarrollo de Software
                case "Desarrollador Junior":

                    habilidadesRequeridas[0] = "Python";
                    habilidadesRequeridas[1] = "JavaScript";
                    habilidadesRequeridas[2] = "Git";
                    habilidadesRequeridas[3] = "SQL";
                    habilidadesExtras[0] = "React";
                    habilidadesExtras[1] = "Docker";

                    break;

                case "Desarrollador Full Stack":

                    habilidadesRequeridas[0] = "Python";
                    habilidadesRequeridas[1] = "JavaScript";
                    habilidadesRequeridas[2] = "React";
                    habilidadesRequeridas[3] = "Docker";
                    habilidadesExtras[0] = "Git";
                    habilidadesExtras[1] = "SQL";

                    break;

                case "Arquitecto de Software":

                    habilidadesRequeridas[0] = "Python";
                    habilidadesRequeridas[1] = "Microservicios";
                    habilidadesRequeridas[2] = "Kubernetes";
                    habilidadesRequeridas[3] = "Diseño de arquitectura";
                    habilidadesExtras[0] = "AWS";
                    habilidadesExtras[1] = "Docker";

                    break;
               
                // Soporte Técnico
                case "Técnico de Soporte":

                    habilidadesRequeridas[0] = "Diagnóstico de hardware";
                    habilidadesRequeridas[1] = "Redes básicas";
                    habilidadesRequeridas[2] = "Microsoft 365";
                    habilidadesRequeridas[3] = "Atención al usuario";
                    habilidadesExtras[0] = "Linux";
                    habilidadesExtras[1] = "Inglés";

                    break;

                case "Administrador de Redes":

                    habilidadesRequeridas[0] = "Cisco";
                    habilidadesRequeridas[1] = "Windows Server";
                    habilidadesRequeridas[2] = "Active Directory";
                    habilidadesRequeridas[3] = "VLAN";
                    habilidadesExtras[0] = "Linux";
                    habilidadesExtras[1] = "AWS";

                    break;

                case "Ingeniero de Infraestructura":

                    habilidadesRequeridas[0] = "Linux";
                    habilidadesRequeridas[1] = "AWS";
                    habilidadesRequeridas[2] = "VMware";
                    habilidadesRequeridas[3] = "Kubernetes";
                    habilidadesExtras[0] = "Docker";
                    habilidadesExtras[1] = "Python";

                    break;
            }
        }

        public string[] ObtenerPuestos(string departamento)
        {
            string[] puestos = new string[3];

            switch (departamento)
            {
                case "Recursos Humanos":

                    puestos[0] = "Asistente de Recursos Humanos";
                    puestos[1] = "Analista de Recursos Humanos";
                    puestos[2] = "Jefe de Recursos Humanos";

                    break;

                case "Desarrollo de Software":

                    puestos[0] = "Desarrollador Junior";
                    puestos[1] = "Desarrollador Full Stack";
                    puestos[2] = "Arquitecto de Software";

                    break;


                case "Soporte Técnico":

                    puestos[0] = "Técnico de Soporte";
                    puestos[1] = "Administrador de Redes";
                    puestos[2] = "Ingeniero de Infraestructura";

                    break;
            }

            return puestos;
        }
    }
}
