﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Final
{
    public class Usuario
    {
        // Arreglos que almacenan la información de los usuarios
        private string[] usuarios;
        private string[] contrasenas;
        private string[] departamentos;

        public Usuario()
        {
            usuarios = new string[4]
            {
                "A.Rios",
                "V.Suarez",
                "J.Santana",
                "G.Icaza"
            };

            contrasenas = new string[4]
            {
                "C793!",
                "C1167!",
                "C1043!",
                "C1124!"
            };

            departamentos = new string[4]
           {
                "Recursos Humanos",
                "Desarrollo de Software",
                 "Desarrollo de Software",
                "Soporte Técnico"
           };

        }

        // Verifica si el usuario y la contraseña existen
        public bool ValidarUsuario(string usuario, string contrasena)
        {

            for (int i = 0; i < usuarios.Length; i++)
            {
                if (usuario == usuarios[i] &&
                    contrasena == contrasenas[i])
                {
                    return true;
                }

            }

            return false;
        }

       // Devuelve el departamento al que pertenece el usuario
        public string ObtenerDepartamento(string usuario)
        {
            for (int i = 0; i < usuarios.Length; i++)
            {
                if (usuario == usuarios[i])
                {
                    return departamentos[i];
                }
            }
            return "";
        }
    }
}
