﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Final
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            this.Load += Form5_Load;
            this.pbAtras3.Click += PbAtras_Click;
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            ConfigurarColumnas();
            CargarCandidatos();
            CargarSeleccionados();
            ConfigurarColumnasSeleccionados();
        }

        private void ConfigurarColumnas()
        {
            Column1.HeaderText = "Nombre";
            Column2.HeaderText = "Cédula";
            Column3.HeaderText = "Correo";
            Column4.HeaderText = "Vacante";
            Column5.HeaderText = "Puntaje";

            dataGridViewResultados.ReadOnly = true;
            dataGridViewResultados.AllowUserToAddRows = false;
        }

        private void CargarCandidatos()
        {
            dataGridViewResultados.Rows.Clear();

            Candidato[] candidatos = Form1.evaluacion.ObtenerCandidatos();
            int cantidad = Form1.evaluacion.CantidadCandidatos();

            for (int i = 0; i < cantidad; i++)
            {
                if (candidatos[i] != null)
                {
                    Candidato candidato = candidatos[i];

                    dataGridViewResultados.Rows.Add(
                        candidato.Nombre,
                        candidato.Cedula,
                        candidato.Correo,
                        candidato.Vacante,
                        candidato.Puntaje
                    );
                }
            }
        }

        private void ConfigurarColumnasSeleccionados()
        {
            Columna1.HeaderText = "Vacante";
            Columna2.HeaderText = "Nombre";
            Columna3.HeaderText = "Correo";
            Columna4.HeaderText = "Puntaje";

            dataGridViewSeleccionados.ReadOnly = true;
            dataGridViewSeleccionados.AllowUserToAddRows = false;
        }

        private void CargarSeleccionados()
        {
            dataGridViewSeleccionados.Rows.Clear();

            Vacante[] vacantes = Form1.evaluacion.ObtenerVacantes();
            int cantidadVacantes = Form1.evaluacion.CantidadVacantes();

            for (int i = 0; i < cantidadVacantes; i++)
            {
                Vacante vacante = vacantes[i];
                Candidato[] seleccionados = Form1.evaluacion.ObtenerSeleccionados(vacante);

                for (int k = 0; k < seleccionados.Length; k++)
                {
                    if (seleccionados[k] != null)
                    {
                        dataGridViewSeleccionados.Rows.Add(
                            vacante.NombrePuesto,
                            seleccionados[k].Nombre,
                            seleccionados[k].Correo,
                            seleccionados[k].Puntaje
                        );
                    }
                }
            }
        }

        private void PbAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}