﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Final
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            CargarVacantes();
        }

        // Configuración de combobox de Vacantes disponibles
        private void CargarVacantes()
        {
            cbVacantes.Items.Clear();


            for (int i = 0; i < Form1.evaluacion.CantidadVacantes(); i++)
            {
                string puesto = Form1.evaluacion.ObtenerVacantes()[i].NombrePuesto;
                bool existe = false;
                for (int j = 0; j < cbVacantes.Items.Count; j++)
                {
                    if (cbVacantes.Items[j].ToString() == puesto)
                    {
                        existe = true;
                        break;
                    }
                }

                if (!existe)
                {
                    cbVacantes.Items.Add(puesto);
                }
            }

            if (cbVacantes.Items.Count == 0)
            {
                cbVacantes.Items.Add("No hay vacantes disponibles");
                cbVacantes.SelectedIndex = 0;
                btRegistrar.Enabled = false;
            }
            else
            {
                cbVacantes.SelectedIndex = 0;
                btRegistrar.Enabled = true;
            }
        }

        // Abre el formulario para crear una nueva vacante
        private void BtNuevaVacante_Click(object sender, EventArgs e)
        {
            Form3 formulario = new Form3();
            formulario.ShowDialog();
            CargarVacantes();
        }

        // Abre el formulario para registrar un candidato
        private void BtRegistrar_Click(object sender, EventArgs e)
        {
            if (cbVacantes.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccione una vacante.");
                return;
            }

            string puestoSeleccionado = cbVacantes.Text;
            Form4 formulario = new Form4(puestoSeleccionado);
            formulario.ShowDialog();

        }

        // Abre el formulario de resultados de las evaluaciones
        private void BtSolicitudes_Click(object sender, EventArgs e)
        {
            if (Form1.evaluacion.CantidadCandidatos() == 0)
            {
                MessageBox.Show(
                    "No hay candidatos Evaluados.",
                    "Sistema de selección",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }
            Form5 formulario = new Form5();
            formulario.Show();
        }
    }
}