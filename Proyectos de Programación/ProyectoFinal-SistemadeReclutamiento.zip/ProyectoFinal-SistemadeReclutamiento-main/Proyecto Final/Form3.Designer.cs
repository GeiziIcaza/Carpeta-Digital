﻿namespace Proyecto_Final
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panVacanteNueva = new System.Windows.Forms.Panel();
            this.pbAtras1 = new System.Windows.Forms.PictureBox();
            this.lbNuevaVacante = new System.Windows.Forms.Label();
            this.lbSphere4 = new System.Windows.Forms.Label();
            this.lBCode4 = new System.Windows.Forms.Label();
            this.pbLogo3 = new System.Windows.Forms.PictureBox();
            this.lbTituloInformacion = new System.Windows.Forms.Label();
            this.lbNombrePuesto = new System.Windows.Forms.Label();
            this.lbSeccion = new System.Windows.Forms.Label();
            this.lbSalario = new System.Windows.Forms.Label();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtExperienciaSolicitada = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panHabilidades = new System.Windows.Forms.Panel();
            this.lbHabilidades = new System.Windows.Forms.Label();
            this.btGuardarVacante = new System.Windows.Forms.Button();
            this.btLimpiar = new System.Windows.Forms.Button();
            this.cbPuesto = new System.Windows.Forms.ComboBox();
            this.lbTituloHabilidades = new System.Windows.Forms.Label();
            this.txtSeccion = new System.Windows.Forms.TextBox();
            this.lbPlazas = new System.Windows.Forms.Label();
            this.cbNivelAcademico = new System.Windows.Forms.ComboBox();
            this.lbExperienciaMinima = new System.Windows.Forms.Label();
            this.numPlazas = new System.Windows.Forms.NumericUpDown();
            this.lbNivelAcademico = new System.Windows.Forms.Label();
            this.panVacanteNueva.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAtras1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo3)).BeginInit();
            this.panHabilidades.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPlazas)).BeginInit();
            this.SuspendLayout();
            // 
            // panVacanteNueva
            // 
            this.panVacanteNueva.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.panVacanteNueva.Controls.Add(this.pbAtras1);
            this.panVacanteNueva.Controls.Add(this.lbNuevaVacante);
            this.panVacanteNueva.Controls.Add(this.lbSphere4);
            this.panVacanteNueva.Controls.Add(this.lBCode4);
            this.panVacanteNueva.Controls.Add(this.pbLogo3);
            this.panVacanteNueva.Location = new System.Drawing.Point(0, 1);
            this.panVacanteNueva.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panVacanteNueva.Name = "panVacanteNueva";
            this.panVacanteNueva.Size = new System.Drawing.Size(1172, 105);
            this.panVacanteNueva.TabIndex = 1;
            // 
            // pbAtras1
            // 
            this.pbAtras1.Image = global::Proyecto_Final.Properties.Resources.atras;
            this.pbAtras1.InitialImage = null;
            this.pbAtras1.Location = new System.Drawing.Point(37, 35);
            this.pbAtras1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbAtras1.Name = "pbAtras1";
            this.pbAtras1.Size = new System.Drawing.Size(70, 52);
            this.pbAtras1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbAtras1.TabIndex = 18;
            this.pbAtras1.TabStop = false;
            this.pbAtras1.Click += new System.EventHandler(this.PbAtras1_Click);
            // 
            // lbNuevaVacante
            // 
            this.lbNuevaVacante.AutoSize = true;
            this.lbNuevaVacante.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNuevaVacante.ForeColor = System.Drawing.Color.White;
            this.lbNuevaVacante.Location = new System.Drawing.Point(123, 48);
            this.lbNuevaVacante.Name = "lbNuevaVacante";
            this.lbNuevaVacante.Size = new System.Drawing.Size(297, 26);
            this.lbNuevaVacante.TabIndex = 17;
            this.lbNuevaVacante.Text = "Crear Solicitud de Vacante";
            // 
            // lbSphere4
            // 
            this.lbSphere4.AutoSize = true;
            this.lbSphere4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSphere4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(189)))), ((int)(((byte)(248)))));
            this.lbSphere4.Location = new System.Drawing.Point(1047, 35);
            this.lbSphere4.Name = "lbSphere4";
            this.lbSphere4.Size = new System.Drawing.Size(98, 29);
            this.lbSphere4.TabIndex = 5;
            this.lbSphere4.Text = "Sphere";
            // 
            // lBCode4
            // 
            this.lBCode4.AutoSize = true;
            this.lBCode4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lBCode4.ForeColor = System.Drawing.Color.White;
            this.lBCode4.Location = new System.Drawing.Point(978, 35);
            this.lBCode4.Name = "lBCode4";
            this.lBCode4.Size = new System.Drawing.Size(76, 29);
            this.lBCode4.TabIndex = 4;
            this.lBCode4.Text = "Code";
            // 
            // pbLogo3
            // 
            this.pbLogo3.Image = global::Proyecto_Final.Properties.Resources.Captura_de_pantalla_2026_07_11_163634;
            this.pbLogo3.Location = new System.Drawing.Point(854, 12);
            this.pbLogo3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pbLogo3.Name = "pbLogo3";
            this.pbLogo3.Size = new System.Drawing.Size(118, 74);
            this.pbLogo3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogo3.TabIndex = 3;
            this.pbLogo3.TabStop = false;
            // 
            // lbTituloInformacion
            // 
            this.lbTituloInformacion.AutoSize = true;
            this.lbTituloInformacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTituloInformacion.ForeColor = System.Drawing.Color.White;
            this.lbTituloInformacion.Location = new System.Drawing.Point(43, 137);
            this.lbTituloInformacion.Name = "lbTituloInformacion";
            this.lbTituloInformacion.Size = new System.Drawing.Size(335, 26);
            this.lbTituloInformacion.TabIndex = 18;
            this.lbTituloInformacion.Text = "INFORMACION DEL PUESTO";
            // 
            // lbNombrePuesto
            // 
            this.lbNombrePuesto.AutoSize = true;
            this.lbNombrePuesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNombrePuesto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbNombrePuesto.Location = new System.Drawing.Point(43, 280);
            this.lbNombrePuesto.Name = "lbNombrePuesto";
            this.lbNombrePuesto.Size = new System.Drawing.Size(210, 25);
            this.lbNombrePuesto.TabIndex = 19;
            this.lbNombrePuesto.Text = "Nombre del puesto";
            // 
            // lbSeccion
            // 
            this.lbSeccion.AutoSize = true;
            this.lbSeccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSeccion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbSeccion.Location = new System.Drawing.Point(43, 195);
            this.lbSeccion.Name = "lbSeccion";
            this.lbSeccion.Size = new System.Drawing.Size(264, 25);
            this.lbSeccion.TabIndex = 21;
            this.lbSeccion.Text = "Sección / Departamento";
            // 
            // lbSalario
            // 
            this.lbSalario.AutoSize = true;
            this.lbSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSalario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbSalario.Location = new System.Drawing.Point(109, 406);
            this.lbSalario.Name = "lbSalario";
            this.lbSalario.Size = new System.Drawing.Size(86, 25);
            this.lbSalario.TabIndex = 23;
            this.lbSalario.Text = "Salario";
            // 
            // txtSalario
            // 
            this.txtSalario.BackColor = System.Drawing.Color.White;
            this.txtSalario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalario.ForeColor = System.Drawing.Color.Black;
            this.txtSalario.Location = new System.Drawing.Point(82, 445);
            this.txtSalario.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSalario.MaxLength = 6;
            this.txtSalario.Multiline = true;
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(148, 37);
            this.txtSalario.TabIndex = 24;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.label7.Location = new System.Drawing.Point(39, 416);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 38);
            this.label7.TabIndex = 25;
            // 
            // txtExperienciaSolicitada
            // 
            this.txtExperienciaSolicitada.BackColor = System.Drawing.Color.White;
            this.txtExperienciaSolicitada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtExperienciaSolicitada.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExperienciaSolicitada.ForeColor = System.Drawing.Color.Black;
            this.txtExperienciaSolicitada.Location = new System.Drawing.Point(434, 444);
            this.txtExperienciaSolicitada.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtExperienciaSolicitada.MaxLength = 2;
            this.txtExperienciaSolicitada.Multiline = true;
            this.txtExperienciaSolicitada.Name = "txtExperienciaSolicitada";
            this.txtExperienciaSolicitada.Size = new System.Drawing.Size(148, 38);
            this.txtExperienciaSolicitada.TabIndex = 26;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.label9.Location = new System.Drawing.Point(65, 978);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(292, 25);
            this.label9.TabIndex = 28;
            this.label9.Text = "Nivel académico requerido";
            // 
            // panHabilidades
            // 
            this.panHabilidades.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(41)))), ((int)(((byte)(59)))));
            this.panHabilidades.Controls.Add(this.lbHabilidades);
            this.panHabilidades.Location = new System.Drawing.Point(722, 179);
            this.panHabilidades.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panHabilidades.Name = "panHabilidades";
            this.panHabilidades.Size = new System.Drawing.Size(404, 275);
            this.panHabilidades.TabIndex = 30;
            // 
            // lbHabilidades
            // 
            this.lbHabilidades.AutoSize = true;
            this.lbHabilidades.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHabilidades.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbHabilidades.Location = new System.Drawing.Point(26, 31);
            this.lbHabilidades.Name = "lbHabilidades";
            this.lbHabilidades.Size = new System.Drawing.Size(0, 25);
            this.lbHabilidades.TabIndex = 0;
            // 
            // btGuardarVacante
            // 
            this.btGuardarVacante.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(99)))), ((int)(((byte)(235)))));
            this.btGuardarVacante.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btGuardarVacante.ForeColor = System.Drawing.Color.White;
            this.btGuardarVacante.Location = new System.Drawing.Point(770, 606);
            this.btGuardarVacante.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btGuardarVacante.Name = "btGuardarVacante";
            this.btGuardarVacante.Size = new System.Drawing.Size(270, 55);
            this.btGuardarVacante.TabIndex = 31;
            this.btGuardarVacante.Text = "Guardar Vacante";
            this.btGuardarVacante.UseVisualStyleBackColor = false;
            this.btGuardarVacante.Click += new System.EventHandler(this.BtGuardarVacante_Click);
            // 
            // btLimpiar
            // 
            this.btLimpiar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.btLimpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLimpiar.ForeColor = System.Drawing.Color.White;
            this.btLimpiar.Location = new System.Drawing.Point(770, 507);
            this.btLimpiar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btLimpiar.Name = "btLimpiar";
            this.btLimpiar.Size = new System.Drawing.Size(270, 55);
            this.btLimpiar.TabIndex = 32;
            this.btLimpiar.Text = "Limpiar";
            this.btLimpiar.UseVisualStyleBackColor = false;
            this.btLimpiar.Click += new System.EventHandler(this.BtLimpiar_Click);
            // 
            // cbPuesto
            // 
            this.cbPuesto.BackColor = System.Drawing.Color.White;
            this.cbPuesto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPuesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPuesto.FormattingEnabled = true;
            this.cbPuesto.Location = new System.Drawing.Point(48, 310);
            this.cbPuesto.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbPuesto.Name = "cbPuesto";
            this.cbPuesto.Size = new System.Drawing.Size(391, 33);
            this.cbPuesto.TabIndex = 33;
            this.cbPuesto.SelectedIndexChanged += new System.EventHandler(this.CbPuesto_SelectedIndexChanged);
            // 
            // lbTituloHabilidades
            // 
            this.lbTituloHabilidades.AutoSize = true;
            this.lbTituloHabilidades.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTituloHabilidades.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbTituloHabilidades.Location = new System.Drawing.Point(825, 138);
            this.lbTituloHabilidades.Name = "lbTituloHabilidades";
            this.lbTituloHabilidades.Size = new System.Drawing.Size(136, 25);
            this.lbTituloHabilidades.TabIndex = 34;
            this.lbTituloHabilidades.Text = "Habilidades";
            // 
            // txtSeccion
            // 
            this.txtSeccion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.txtSeccion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSeccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeccion.ForeColor = System.Drawing.Color.White;
            this.txtSeccion.Location = new System.Drawing.Point(48, 224);
            this.txtSeccion.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSeccion.MaxLength = 30;
            this.txtSeccion.Multiline = true;
            this.txtSeccion.Name = "txtSeccion";
            this.txtSeccion.Size = new System.Drawing.Size(602, 38);
            this.txtSeccion.TabIndex = 36;
            // 
            // lbPlazas
            // 
            this.lbPlazas.AutoSize = true;
            this.lbPlazas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPlazas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbPlazas.Location = new System.Drawing.Point(482, 280);
            this.lbPlazas.Name = "lbPlazas";
            this.lbPlazas.Size = new System.Drawing.Size(215, 25);
            this.lbPlazas.TabIndex = 38;
            this.lbPlazas.Text = "Cantidad de plazas";
            // 
            // cbNivelAcademico
            // 
            this.cbNivelAcademico.BackColor = System.Drawing.Color.White;
            this.cbNivelAcademico.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbNivelAcademico.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbNivelAcademico.FormattingEnabled = true;
            this.cbNivelAcademico.Items.AddRange(new object[] {
            "Bachiller",
            "Técnico ",
            "Licenciatura",
            "Posgrado",
            "Maestría",
            "Doctorado"});
            this.cbNivelAcademico.Location = new System.Drawing.Point(48, 582);
            this.cbNivelAcademico.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbNivelAcademico.Name = "cbNivelAcademico";
            this.cbNivelAcademico.Size = new System.Drawing.Size(447, 33);
            this.cbNivelAcademico.TabIndex = 40;
            // 
            // lbExperienciaMinima
            // 
            this.lbExperienciaMinima.AutoSize = true;
            this.lbExperienciaMinima.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbExperienciaMinima.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbExperienciaMinima.Location = new System.Drawing.Point(354, 406);
            this.lbExperienciaMinima.Name = "lbExperienciaMinima";
            this.lbExperienciaMinima.Size = new System.Drawing.Size(284, 25);
            this.lbExperienciaMinima.TabIndex = 41;
            this.lbExperienciaMinima.Text = "Experiencia minima(años)";
            // 
            // numPlazas
            // 
            this.numPlazas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.numPlazas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numPlazas.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.numPlazas.Location = new System.Drawing.Point(553, 317);
            this.numPlazas.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numPlazas.Name = "numPlazas";
            this.numPlazas.Size = new System.Drawing.Size(114, 30);
            this.numPlazas.TabIndex = 42;
            this.numPlazas.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lbNivelAcademico
            // 
            this.lbNivelAcademico.AutoSize = true;
            this.lbNivelAcademico.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNivelAcademico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(116)))), ((int)(((byte)(139)))));
            this.lbNivelAcademico.Location = new System.Drawing.Point(43, 553);
            this.lbNivelAcademico.Name = "lbNivelAcademico";
            this.lbNivelAcademico.Size = new System.Drawing.Size(187, 25);
            this.lbNivelAcademico.TabIndex = 43;
            this.lbNivelAcademico.Text = "Nivel Académico";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(41)))));
            this.ClientSize = new System.Drawing.Size(1170, 727);
            this.Controls.Add(this.lbNivelAcademico);
            this.Controls.Add(this.numPlazas);
            this.Controls.Add(this.lbExperienciaMinima);
            this.Controls.Add(this.cbNivelAcademico);
            this.Controls.Add(this.lbPlazas);
            this.Controls.Add(this.txtSeccion);
            this.Controls.Add(this.lbTituloHabilidades);
            this.Controls.Add(this.cbPuesto);
            this.Controls.Add(this.btLimpiar);
            this.Controls.Add(this.btGuardarVacante);
            this.Controls.Add(this.panHabilidades);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtExperienciaSolicitada);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.lbSalario);
            this.Controls.Add(this.lbSeccion);
            this.Controls.Add(this.lbNombrePuesto);
            this.Controls.Add(this.lbTituloInformacion);
            this.Controls.Add(this.panVacanteNueva);
            this.ForeColor = System.Drawing.SystemColors.GrayText;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Form3";
            this.Text = "Nueva Vacante";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panVacanteNueva.ResumeLayout(false);
            this.panVacanteNueva.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAtras1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo3)).EndInit();
            this.panHabilidades.ResumeLayout(false);
            this.panHabilidades.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPlazas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panVacanteNueva;
        private System.Windows.Forms.Label lbSphere4;
        private System.Windows.Forms.Label lBCode4;
        private System.Windows.Forms.PictureBox pbLogo3;
        private System.Windows.Forms.Label lbNuevaVacante;
        private System.Windows.Forms.Label lbTituloInformacion;
        private System.Windows.Forms.Label lbNombrePuesto;
        private System.Windows.Forms.Label lbSeccion;
        private System.Windows.Forms.Label lbSalario;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtExperienciaSolicitada;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panHabilidades;
        private System.Windows.Forms.Button btGuardarVacante;
        private System.Windows.Forms.Button btLimpiar;
        private System.Windows.Forms.ComboBox cbPuesto;
        private System.Windows.Forms.Label lbHabilidades;
        private System.Windows.Forms.Label lbTituloHabilidades;
        private System.Windows.Forms.TextBox txtSeccion;
        private System.Windows.Forms.PictureBox pbAtras1;
        private System.Windows.Forms.Label lbPlazas;
        private System.Windows.Forms.ComboBox cbNivelAcademico;
        private System.Windows.Forms.Label lbExperienciaMinima;
        private System.Windows.Forms.NumericUpDown numPlazas;
        private System.Windows.Forms.Label lbNivelAcademico;
    }
}