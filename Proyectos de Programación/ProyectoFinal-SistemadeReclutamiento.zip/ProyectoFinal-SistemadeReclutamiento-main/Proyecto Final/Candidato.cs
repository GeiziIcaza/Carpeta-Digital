﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Final
{
    public class Candidato
    {
        private string nombre;
        private string cedula;
        private string correo;
        private int experiencia;
        private string vacante;
        private string[] habilidades;

        private int puntajeHabilidades;
        private int puntajeEntrevista;
        private int puntajeTotal;

        private string nivelAcademico;
        private double aspiracionSalarial;

        public Candidato()
        {
            habilidades = new string[6];
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public string Cedula
        {
            get { return cedula; }
            set { cedula = value; }
        }

        public string Correo
        {
            get { return correo; }
            set { correo = value; }
        }

        public int Experiencia
        {
            get { return experiencia; }
            set { experiencia = value; }
        }

        public string Vacante
        {
            get { return vacante; }
            set { vacante = value; }
        }

        public string NivelAcademico
        {
            get { return nivelAcademico; }
            set { nivelAcademico = value; }
        }

        public double AspiracionSalarial
        {
            get { return aspiracionSalarial; }
            set { aspiracionSalarial = value; }
        }

        public string[] Habilidades
        {
            get { return habilidades; }
            set { habilidades = value; }
        }

        public int PuntajeHabilidades
        {
            get { return puntajeHabilidades; }
            set { puntajeHabilidades = value; }
        }

        public int PuntajeEntrevista
        {
            get { return puntajeEntrevista; }
            set { puntajeEntrevista = value; }
        }

        public int PuntajeTotal
        {
            get { return puntajeTotal; }
            set { puntajeTotal = value; }
        }

        public int Puntaje
        {
            get { return puntajeTotal; }
            set { puntajeTotal = value; }
        }

        // Puntaje por habilidades
     
        public int CalcularPuntajeHabilidades(bool[] habilidadesMarcadas)
        {
            int puntaje = 0;

            // Requeridas
            for (int i = 0; i < 4; i++)
            {
                if (habilidadesMarcadas[i])
                    puntaje += 10;
            }

            // Extras
            for (int i = 4; i < 6; i++)
            {
                if (habilidadesMarcadas[i])
                    puntaje += 5;
            }

            PuntajeHabilidades = puntaje;
            return puntaje;
        }

        // Puntaje total
       
        public int CalcularPuntajeTotal(
            Vacante vacante,
            bool[] habilidadesMarcadas,
            int presentacion,
            int comunicacion,
            int actitud,
            int aspiracionProfesional)
        {
            int puntaje = 0;
            int habilidadesRequeridas = 0;

            for (int i = 0; i < 4; i++)
            {
                if (habilidadesMarcadas[i])
                    habilidadesRequeridas++;
            }

            // Descartes
            if (Experiencia < vacante.Experiencia)
            {
                PuntajeTotal = 0;
                return 0;
            }

            if (habilidadesRequeridas < 3)
            {
                PuntajeTotal = 0;
                return 0;
            }

            if (AspiracionSalarial > vacante.Salario + 50)
            {
                PuntajeTotal = 0;
                return 0;
            }

            int puntajeNivel = CalcularPuntajeNivelAcademico(vacante);

            if (puntajeNivel == -1)
            {
                PuntajeTotal = 0;
                return 0;
            }

            // Habilidades
            puntaje += CalcularPuntajeHabilidades(habilidadesMarcadas);

            // Entrevista
            PuntajeEntrevista =
                presentacion +
                comunicacion +
                actitud +
                aspiracionProfesional;

            puntaje += PuntajeEntrevista;

            // Nivel académico
            puntaje += puntajeNivel;

            // Experiencia
            puntaje += CalcularPuntajeExperiencia(vacante);

            // Aspiración salarial
            if (AspiracionSalarial < vacante.Salario)
                puntaje += 10;
            else if (AspiracionSalarial == vacante.Salario)
                puntaje += 5;

            PuntajeTotal = puntaje;

            return puntaje;
        }


        // Nivel académico
        private int CalcularPuntajeNivelAcademico(Vacante vacante)
        {
            int nivelCandidato = ObtenerNivelAcademico(NivelAcademico);
            int nivelRequerido = ObtenerNivelAcademico(vacante.NivelAcademico);

           
            if (nivelCandidato < nivelRequerido)
            {
                return -1;
            }

            if (nivelCandidato > nivelRequerido)
            {
                return 10;
            }

            return 0;
        }



         private int ObtenerNivelAcademico(string nivel)
        {
            nivel = nivel.ToLower();

            if (nivel.Contains("bachiller"))
            {
                return 1;
            }

            if (nivel.Contains("técnico") || nivel.Contains("tecnico"))
            {
                return 2;
            }

            if (nivel.Contains("licenciatura"))
            {
                return 3;
            }

            if (nivel.Contains("posgrado"))
            {
                return 4;
            }

            if (nivel.Contains("maestría") || nivel.Contains("maestria"))
            {
                return 5;
            }

            if (nivel.Contains("doctorado"))
            {
                return 6;
            }

            return 0;
        }


        // Experiencia

        private int CalcularPuntajeExperiencia(Vacante vacante)
        {
            int experienciaExtra = Experiencia - vacante.Experiencia;

            if (experienciaExtra <= 0)
                return 0;

            if (experienciaExtra > 5)
                return 10;

            return experienciaExtra;
        }
    }
}


